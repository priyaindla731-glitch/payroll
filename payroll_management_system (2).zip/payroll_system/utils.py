"""utils.py - security, translations, styling, HTML helpers and PDF generation."""
import base64
import calendar
import hashlib
import hmac
import html
import io
import os
import zipfile
from datetime import date, datetime

import pandas as pd
import streamlit as st
from PIL import Image, ImageOps
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Image as RLImage
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

PALETTE = ["#7c3aed", "#ec4899", "#3b82f6", "#a78bfa", "#f472b6", "#60a5fa", "#8b5cf6", "#f9a8d4"]

# --------------------------------------------------------------------------- #
# Passwords & permissions
# --------------------------------------------------------------------------- #
def hash_password(password, salt=None, iterations=200_000):
    salt = salt or os.urandom(16).hex()
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), iterations).hex()
    return f"pbkdf2_sha256${iterations}${salt}${dk}"


def verify_password(password, stored):
    try:
        _, iters, salt, dk = stored.split("$")
        test = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(iters)).hex()
        return hmac.compare_digest(test, dk)
    except Exception:
        return False


HR_ALLOWED = {
    "dashboard", "employees", "payroll", "payslips", "attendance", "leaves", "performance", "training",
    "holidays", "documents", "loans", "reimbursements", "resignations", "reports", "settings",
    "edit_employee", "process_payroll", "approve_leave", "approve_reimbursement",
}
# Admin-only: audit page, approve_payroll, delete_employee, complete_settlement,
# manage_users, company_settings, payroll_settings, backup.


def can(role, action):
    return role == "admin" or (role == "hr" and action in HR_ALLOWED)


# --------------------------------------------------------------------------- #
# Translations (navigation, headings and key labels). Missing keys fall back to English.
# --------------------------------------------------------------------------- #
LANGS = {"en": "English", "te": "తెలుగు (Telugu)", "hi": "हिन्दी (Hindi)"}

TR = {
    "en": {
        "dashboard": "Dashboard", "employees": "Employees", "payroll": "Payroll", "payslips": "Payslips",
        "attendance": "Attendance", "leaves": "Leave Management", "performance": "Performance Reviews",
        "training": "Training & Certifications", "holidays": "Holiday Calendar", "documents": "Document Expiry",
        "loans": "Loans & Advances", "reimbursements": "Reimbursements", "resignations": "Resignation & Settlement",
        "reports": "Reports & Analytics", "audit": "Audit Logs", "settings": "Settings",
        "app_title": "PayrollPro", "login": "Login", "username": "Username", "password": "Password",
        "sign_in": "Sign in", "logout": "Logout", "language": "Language", "dark_mode": "Dark mode",
        "total_employees": "Total Employees", "monthly_payroll": "Monthly Payroll",
        "attendance_pct": "Attendance", "pending_leaves": "Pending Leaves", "net_salary": "Net Salary",
        "quick_actions": "Quick Actions", "recent_activity": "Recent Activity",
        "upcoming_birthdays": "Upcoming Birthdays", "alerts": "Alerts", "payroll_status": "Payroll Status",
        "welcome": "Welcome", "save": "Save", "search": "Search", "download": "Download",
    },
    "te": {
        "dashboard": "డాష్‌బోర్డ్", "employees": "ఉద్యోగులు", "payroll": "పేరోల్", "payslips": "పేస్లిప్‌లు",
        "attendance": "హాజరు", "leaves": "సెలవుల నిర్వహణ", "performance": "పనితీరు సమీక్షలు",
        "training": "శిక్షణ & సర్టిఫికేషన్లు", "holidays": "సెలవు దినాల క్యాలెండర్", "documents": "పత్రాల గడువు",
        "loans": "రుణాలు & అడ్వాన్స్‌లు", "reimbursements": "రీయింబర్స్‌మెంట్లు",
        "resignations": "రాజీనామా & సెటిల్‌మెంట్", "reports": "నివేదికలు & విశ్లేషణ", "audit": "ఆడిట్ లాగ్‌లు",
        "settings": "సెట్టింగ్‌లు", "login": "లాగిన్", "username": "వినియోగదారు పేరు", "password": "పాస్‌వర్డ్",
        "sign_in": "సైన్ ఇన్", "logout": "లాగ్ అవుట్", "language": "భాష", "dark_mode": "డార్క్ మోడ్",
        "total_employees": "మొత్తం ఉద్యోగులు", "monthly_payroll": "నెలవారీ పేరోల్", "attendance_pct": "హాజరు శాతం",
        "pending_leaves": "పెండింగ్ సెలవులు", "net_salary": "నికర జీతం", "quick_actions": "త్వరిత చర్యలు",
        "recent_activity": "ఇటీవలి కార్యకలాపాలు", "upcoming_birthdays": "రాబోయే పుట్టినరోజులు",
        "alerts": "హెచ్చరికలు", "payroll_status": "పేరోల్ స్థితి", "welcome": "స్వాగతం",
        "save": "సేవ్ చేయండి", "search": "వెతకండి", "download": "డౌన్‌లోడ్",
    },
    "hi": {
        "dashboard": "डैशबोर्ड", "employees": "कर्मचारी", "payroll": "पेरोल", "payslips": "पेस्लिप",
        "attendance": "उपस्थिति", "leaves": "छुट्टी प्रबंधन", "performance": "प्रदर्शन समीक्षा",
        "training": "प्रशिक्षण और प्रमाणपत्र", "holidays": "अवकाश कैलेंडर", "documents": "दस्तावेज़ समाप्ति",
        "loans": "ऋण और अग्रिम", "reimbursements": "प्रतिपूर्ति", "resignations": "इस्तीफ़ा और निपटान",
        "reports": "रिपोर्ट और विश्लेषण", "audit": "ऑडिट लॉग", "settings": "सेटिंग्स", "login": "लॉगिन",
        "username": "उपयोगकर्ता नाम", "password": "पासवर्ड", "sign_in": "साइन इन", "logout": "लॉग आउट",
        "language": "भाषा", "dark_mode": "डार्क मोड", "total_employees": "कुल कर्मचारी",
        "monthly_payroll": "मासिक पेरोल", "attendance_pct": "उपस्थिति प्रतिशत", "pending_leaves": "लंबित छुट्टियाँ",
        "net_salary": "शुद्ध वेतन", "quick_actions": "त्वरित कार्य", "recent_activity": "हाल की गतिविधि",
        "upcoming_birthdays": "आगामी जन्मदिन", "alerts": "अलर्ट", "payroll_status": "पेरोल स्थिति",
        "welcome": "स्वागत है", "save": "सहेजें", "search": "खोजें", "download": "डाउनलोड",
    },
}


def t(key):
    lang = st.session_state.get("lang", "en")
    return TR.get(lang, {}).get(key) or TR["en"].get(key, key)


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def money(x, cur="₹"):
    try:
        return f"{cur}{float(x):,.2f}"
    except (TypeError, ValueError):
        return f"{cur}0.00"


def to_date(s):
    try:
        return date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def month_label(m):
    try:
        return datetime.strptime(m, "%Y-%m").strftime("%B %Y")
    except (TypeError, ValueError):
        return str(m)


def month_options(n=12, today=None):
    """Last n months including the current one, newest first, as YYYY-MM."""
    today = today or date.today()
    y, m = today.year, today.month
    out = []
    for _ in range(n):
        out.append(f"{y}-{m:02d}")
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return out


def next_birthday(dob, today=None):
    today = today or date.today()
    d = to_date(dob)
    if not d:
        return None
    for yr in (today.year, today.year + 1):
        try:
            nb = d.replace(year=yr)
        except ValueError:  # 29 Feb
            nb = date(yr, 2, 28)
        if nb >= today:
            return nb
    return None


def img_to_bytes(file, size=256):
    """Square-crop and compress an uploaded image to JPEG bytes."""
    im = Image.open(file).convert("RGB")
    im = ImageOps.fit(im, (size, size))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=85)
    return buf.getvalue()


def logo_to_b64(file, max_w=400):
    im = Image.open(file).convert("RGBA")
    if im.width > max_w:
        im = im.resize((max_w, int(im.height * max_w / im.width)))
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return base64.b64encode(buf.getvalue()).decode()


def is_dark():
    return bool(st.session_state.get("dark", False))


# --------------------------------------------------------------------------- #
# Styling
# --------------------------------------------------------------------------- #
CSS = """
<style>
.stApp { background: __BG__; color: __TEXT__; }
.block-container { padding-top: 1.4rem; max-width: 1400px; }
footer { visibility: hidden; }
h1,h2,h3,h4,h5,h6, .stMarkdown p, .stMarkdown li, label, .stCaption, [data-testid="stWidgetLabel"] p { color: __TEXT__; }
[data-testid="stSidebar"] { background: linear-gradient(180deg,#3b0764 0%,#6d28d9 38%,#c026d3 76%,#ec4899 100%); }
[data-testid="stSidebar"] * { color: #ffffff; }
[data-testid="stSidebar"] [data-baseweb="select"] * { color: #1f1537 !important; }
[data-testid="stSidebar"] div[role="radiogroup"] { gap: 3px; }
[data-testid="stSidebar"] div[role="radiogroup"] label { background: rgba(255,255,255,.08); border-radius: 12px;
    padding: 7px 12px; width: 100%; transition: all .2s; cursor: pointer; }
[data-testid="stSidebar"] div[role="radiogroup"] label:hover { background: rgba(255,255,255,.22); transform: translateX(3px); }
[data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked) { background: linear-gradient(90deg,#ffffff,#fce7f3); }
[data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked) * { color: #6d28d9 !important; font-weight: 700; }
[data-testid="stSidebar"] div[role="radiogroup"] label > div:first-child { display: none; }
.stButton > button, .stDownloadButton > button, [data-testid="stFormSubmitButton"] > button {
    background: linear-gradient(90deg,#7c3aed,#ec4899); color: #fff; border: 0; border-radius: 12px;
    font-weight: 600; padding: .5rem 1.1rem; box-shadow: 0 4px 14px rgba(124,58,237,.30); transition: all .2s; }
.stButton > button:hover, .stDownloadButton > button:hover, [data-testid="stFormSubmitButton"] > button:hover {
    transform: translateY(-1px); box-shadow: 0 6px 18px rgba(236,72,153,.40); color: #fff; border: 0; }
[data-testid="stSidebar"] .stButton > button { background: rgba(255,255,255,.18); box-shadow: none; width: 100%; }
.stTextInput input, .stNumberInput input, .stDateInput input, .stTextArea textarea, [data-baseweb="select"] > div { border-radius: 10px; }
.stTabs [data-baseweb="tab-list"] { gap: 6px; flex-wrap: wrap; }
.stTabs [data-baseweb="tab"] { border-radius: 10px 10px 0 0; padding: 8px 14px; font-weight: 600; }
.stTabs [aria-selected="true"] { color: #ec4899 !important; }
.hero { background: linear-gradient(120deg,#6d28d9 0%,#c026d3 55%,#ec4899 100%); color:#fff; border-radius: 20px;
    padding: 20px 26px; margin-bottom: 18px; box-shadow: 0 10px 30px rgba(109,40,217,.30); }
.hero h1 { color:#fff !important; margin:0; font-size: 1.7rem; } .hero p { color:#fce7f3 !important; margin:4px 0 0 0; }
.kpi-grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(190px,1fr)); gap:16px; margin-bottom:18px; }
.kpi { border-radius: 18px; padding: 18px 20px; color:#fff; position:relative; overflow:hidden; box-shadow: 0 8px 22px rgba(0,0,0,.14); }
.kpi .ic { position:absolute; right:14px; top:10px; font-size:2.1rem; opacity:.35; }
.kpi .lb { font-size:.82rem; opacity:.92; letter-spacing:.3px; text-transform:uppercase; }
.kpi .vl { font-size:1.65rem; font-weight:800; margin:4px 0 2px 0; } .kpi .sb { font-size:.78rem; opacity:.9; }
.card { background: __CARD__; border: 1px solid __BORDER__; border-radius: 18px; padding: 16px 18px; margin-bottom: 14px;
    box-shadow: 0 4px 16px rgba(109,40,217,.08); color: __TEXT__; }
.card h4 { margin: 0 0 10px 0; color: __TEXT__; }
.tbl-wrap { overflow-x: auto; border-radius: 14px; border: 1px solid __BORDER__; margin-bottom: 12px; }
table.tbl { border-collapse: collapse; width: 100%; font-size: .87rem; background: __CARD__; }
table.tbl th { background: linear-gradient(90deg,#6d28d9,#c026d3); color:#fff; text-align:left; padding: 9px 12px; white-space: nowrap; }
table.tbl td { padding: 8px 12px; border-bottom: 1px solid __BORDER__; color: __TEXT__; }
table.tbl tr:nth-child(even) td { background: __ZEBRA__; }
.badge { display:inline-block; padding: 2px 10px; border-radius: 999px; font-size: .75rem; font-weight: 700; }
.b-green{background:#d1fae5;color:#047857}.b-amber{background:#fef3c7;color:#b45309}.b-red{background:#fee2e2;color:#b91c1c}
.b-blue{background:#dbeafe;color:#1d4ed8}.b-purple{background:#ede9fe;color:#6d28d9}.b-pink{background:#fce7f3;color:#be185d}
.alert { border-left: 5px solid #ec4899; background: __CARD__; padding: 9px 14px; border-radius: 10px; margin-bottom: 8px; color: __TEXT__; border-top:1px solid __BORDER__; border-right:1px solid __BORDER__; border-bottom:1px solid __BORDER__;}
.alert.warn { border-left-color:#f59e0b } .alert.bad { border-left-color:#ef4444 } .alert.ok { border-left-color:#10b981 }
.avatar { border-radius: 50%; background: linear-gradient(135deg,#7c3aed,#ec4899); color:#fff; display:flex; align-items:center;
    justify-content:center; font-weight:800; }
.cal { border-collapse: collapse; width:100%; text-align:center; background: __CARD__; }
.cal th { background: linear-gradient(90deg,#6d28d9,#c026d3); color:#fff; padding:8px; }
.cal td { border:1px solid __BORDER__; height:62px; vertical-align:top; padding:4px; width:14.28%; color: __TEXT__; font-size:.85rem; }
.cal td.hol { background:#fce7f3; color:#9d174d; font-weight:700 } .cal td.sun { color:#7c3aed } .cal td.today { outline:3px solid #7c3aed; }
.cal small { display:block; font-weight:600; font-size:.68rem; line-height:1.1; }
@media (max-width: 768px) { .block-container { padding: 1rem .8rem; } .hero h1 { font-size: 1.25rem; } .kpi .vl { font-size: 1.3rem; } }
__DARK__
</style>
"""

DARK_EXTRA = """
.stApp, .stApp p, .stApp span, .stApp div[data-testid="stMarkdownContainer"] { color: #f3e8ff; }
.stTextInput input, .stNumberInput input, .stDateInput input, .stTextArea textarea, [data-baseweb="select"] > div,
[data-baseweb="input"] { background-color: #1d1535 !important; color: #f3e8ff !important; }
[data-testid="stSidebar"] [data-baseweb="select"] > div { background-color: #ffffff !important; }
.stTabs [data-baseweb="tab"] { color: #c4b5fd; }
[data-testid="stForm"] { border-color: #3b2a66; }
"""


def get_css(dark=False):
    if dark:
        vals = dict(BG="#120b24", TEXT="#f3e8ff", CARD="#1d1535", BORDER="#3b2a66", ZEBRA="#241a42", DARK=DARK_EXTRA)
    else:
        vals = dict(BG="linear-gradient(135deg,#faf5ff 0%,#fdf2f8 50%,#eff6ff 100%)", TEXT="#1f1537",
                    CARD="#ffffff", BORDER="#ede9fe", ZEBRA="#faf5ff", DARK="")
    css = CSS
    for k, v in vals.items():
        css = css.replace(f"__{k}__", v)
    return css


KPI_GRADS = [("#7c3aed", "#a78bfa"), ("#ec4899", "#f472b6"), ("#3b82f6", "#60a5fa"),
             ("#8b5cf6", "#ec4899"), ("#4f46e5", "#3b82f6"), ("#c026d3", "#f472b6")]


def page_header(icon, title, sub=""):
    return f'<div class="hero"><h1>{icon} {html.escape(title)}</h1><p>{html.escape(sub)}</p></div>'


def kpi_cards(items):
    """items: list of (icon, label, value, sub)."""
    out = ['<div class="kpi-grid">']
    for i, (ic, lb, vl, sb) in enumerate(items):
        a, b = KPI_GRADS[i % len(KPI_GRADS)]
        out.append(f'<div class="kpi" style="background:linear-gradient(135deg,{a},{b})"><div class="ic">{ic}</div>'
                   f'<div class="lb">{html.escape(str(lb))}</div><div class="vl">{html.escape(str(vl))}</div>'
                   f'<div class="sb">{html.escape(str(sb))}</div></div>')
    out.append("</div>")
    return "".join(out)


BADGE = {
    "green": {"active", "approved", "paid", "present", "completed", "settled", "valid", "closed", "work from home"},
    "amber": {"pending", "pending approval", "on leave", "planned", "half day", "in progress", "expiring soon", "leave"},
    "red": {"rejected", "inactive", "absent", "expired", "unpaid leave"},
    "blue": {"holiday", "loan", "training", "national", "salary advance"},
    "purple": {"certification", "company", "optional"},
}


def badge(text):
    low = str(text).lower()
    cls = next((f"b-{c}" for c, names in BADGE.items() if low in names), "b-pink")
    return f'<span class="badge {cls}">{html.escape(str(text))}</span>'


def alert_box(text, kind=""):
    return f'<div class="alert {kind}">{text}</div>'


def avatar_html(name, size=64):
    ini = "".join(p[0] for p in str(name).split()[:2]).upper() or "?"
    return (f'<div class="avatar" style="width:{size}px;height:{size}px;font-size:{size // 2.6:.0f}px">'
            f'{html.escape(ini)}</div>')


def html_table(df, badge_cols=(), max_rows=200, money_cols=(), cur="₹"):
    if df is None or df.empty:
        return '<div class="card">No records to show.</div>'
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in df.columns)
    body = []
    for _, row in df.head(max_rows).iterrows():
        cells = []
        for c in df.columns:
            v = row[c]
            if pd.isna(v):
                v = ""
            if c in badge_cols:
                cells.append(f"<td>{badge(v)}</td>")
            elif c in money_cols and v != "":
                cells.append(f"<td>{html.escape(money(v, cur))}</td>")
            else:
                cells.append(f"<td>{html.escape(str(v))}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    note = f"<small>Showing first {max_rows} of {len(df)} rows.</small>" if len(df) > max_rows else ""
    return f'<div class="tbl-wrap"><table class="tbl"><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>{note}'


def style_fig(fig, height=360):
    dark = is_dark()
    fig.update_layout(template="plotly_dark" if dark else "plotly_white", height=height,
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      colorway=PALETTE, margin=dict(l=10, r=10, t=50, b=10),
                      font=dict(color="#f3e8ff" if dark else "#1f1537"),
                      legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
    return fig


def holiday_calendar_html(year, month, holidays):
    """holidays: dict {date: name}. Returns an HTML month grid."""
    cal = calendar.Calendar(firstweekday=0)
    today = date.today()
    rows = ["<tr>" + "".join(f"<th>{d}</th>" for d in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]) + "</tr>"]
    for week in cal.monthdatescalendar(year, month):
        tds = []
        for d in week:
            if d.month != month:
                tds.append("<td></td>")
                continue
            cls = []
            extra = ""
            if d in holidays:
                cls.append("hol")
                extra = f"<small>{html.escape(holidays[d])}</small>"
            if d.weekday() == 6:
                cls.append("sun")
            if d == today:
                cls.append("today")
            tds.append(f'<td class="{" ".join(cls)}">{d.day}{extra}</td>')
        rows.append("<tr>" + "".join(tds) + "</tr>")
    return f'<div class="tbl-wrap"><table class="cal">{"".join(rows)}</table></div>'


# --------------------------------------------------------------------------- #
# PDF generation (ReportLab, built-in Helvetica => Latin text only)
# --------------------------------------------------------------------------- #
PURPLE = colors.HexColor("#6d28d9")
PINK = colors.HexColor("#ec4899")
LIGHT = colors.HexColor("#f5f3ff")
GRID = colors.HexColor("#ddd6fe")


def _txt(s):
    """Make text safe for the built-in PDF fonts and for Paragraph markup."""
    s = str(s).replace("₹", "Rs. ")
    s = s.encode("latin-1", "replace").decode("latin-1")
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _pm(x, cur):
    c = "Rs. " if cur == "₹" else cur
    try:
        return f"{c}{float(x):,.2f}"
    except (TypeError, ValueError):
        return f"{c}0.00"


def _logo(company, height=14 * mm):
    b64 = company.get("logo_b64")
    if not b64:
        return None
    try:
        raw = base64.b64decode(b64)
        w, h = Image.open(io.BytesIO(raw)).size
        return RLImage(io.BytesIO(raw), width=height * w / h, height=height)
    except Exception:
        return None


def payslip_pdf(company, emp, pay, month):
    """Return bytes of a single-page payslip. company: settings dict, emp/pay: dict-like."""
    cur = company.get("currency", "₹")
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=12 * mm,
                            bottomMargin=12 * mm, title=f"Payslip {emp['emp_id']} {month}")
    W = A4[0] - 30 * mm
    wh = ParagraphStyle("wh", fontName="Helvetica-Bold", fontSize=15, textColor=colors.white, leading=18)
    ws = ParagraphStyle("ws", fontName="Helvetica", fontSize=8, textColor=colors.HexColor("#fce7f3"), leading=10)
    wr = ParagraphStyle("wr", fontName="Helvetica-Bold", fontSize=14, textColor=colors.white, alignment=2, leading=17)
    wrs = ParagraphStyle("wrs", fontName="Helvetica", fontSize=9, textColor=colors.HexColor("#fce7f3"), alignment=2)
    lbl = ParagraphStyle("lbl", fontName="Helvetica", fontSize=8.5, textColor=colors.HexColor("#6b5b95"))
    val = ParagraphStyle("val", fontName="Helvetica-Bold", fontSize=9, textColor=colors.HexColor("#1f1537"))
    story = []
    logo = _logo(company)
    left = [Paragraph(_txt(company.get("company_name", "")), wh),
            Paragraph(_txt(company.get("company_address", "")), ws),
            Paragraph(_txt(f'{company.get("company_phone", "")}  |  {company.get("company_email", "")}'), ws)]
    right = [Paragraph("PAYSLIP", wr), Paragraph(_txt(month_label(month)), wrs)]
    lw = 22 * mm if logo else 1 * mm
    header = Table([[logo or "", left, right]], colWidths=[lw, W - lw - 50 * mm, 50 * mm])
    header.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PURPLE), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                                ("TOPPADDING", (0, 0), (-1, -1), 10), ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                                ("LINEBELOW", (0, 0), (-1, -1), 3, PINK)]))
    story += [header, Spacer(1, 8)]

    def kv(k, v):
        return [Paragraph(_txt(k), lbl), Paragraph(_txt(v), val)]
    info = [kv("Employee Name", emp["name"]) + kv("Employee ID", emp["emp_id"]),
            kv("Department", emp.get("department") or "-") + kv("Designation", emp.get("designation") or "-"),
            kv("Date of Joining", emp.get("joining_date") or "-") + kv("Bank Account", emp.get("bank_account") or "-"),
            kv("Pay Period", month_label(month)) + kv("Loss of Pay Days", f"{pay.get('lop_days', 0):g}")]
    t1 = Table(info, colWidths=[30 * mm, W / 2 - 30 * mm, 30 * mm, W / 2 - 30 * mm])
    t1.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("BOX", (0, 0), (-1, -1), 0.6, GRID),
                            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    story += [t1, Spacer(1, 10)]

    earn = [("Basic Salary", pay["basic"], True), ("House Rent Allowance (HRA)", pay["hra"], True),
            ("Dearness Allowance (DA)", pay["da"], True), ("Allowances", pay["allowances"], False),
            ("Bonus", pay["bonus"], False), ("Overtime", pay["overtime"], False),
            ("Reimbursements", pay["reimbursements"], False)]
    ded = [("Provident Fund (PF)", pay["pf"], True), ("Income Tax", pay["tax"], False),
           ("Professional Tax", pay["prof_tax"], False), ("Loan EMI", pay["loan_ded"], False),
           ("Salary Advance Recovery", pay["advance_ded"], False),
           (f"Loss of Pay ({pay.get('lop_days', 0):g} days)", pay["lop_amount"], False),
           ("Other Deductions", pay["other_ded"], False)]
    er = [(a, b) for a, b, keep in earn if keep or b]
    dr = [(a, b) for a, b, keep in ded if keep or b]
    n = max(len(er), len(dr))
    er += [("", None)] * (n - len(er))
    dr += [("", None)] * (n - len(dr))
    rows = [["EARNINGS", "AMOUNT", "DEDUCTIONS", "AMOUNT"]]
    for (a, b), (c, d) in zip(er, dr):
        rows.append([a, "" if b is None else _pm(b, cur), c, "" if d is None else _pm(d, cur)])
    rows.append(["Gross Earnings", _pm(pay["gross"], cur), "Total Deductions", _pm(pay["total_ded"], cur)])
    t2 = Table(rows, colWidths=[W * 0.31, W * 0.19, W * 0.31, W * 0.19], repeatRows=1)
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), PURPLE), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"), ("ALIGN", (3, 0), (3, -1), "RIGHT"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, LIGHT]),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#ede9fe")), ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("LINEAFTER", (1, 0), (1, -1), 0.8, GRID), ("BOX", (0, 0), (-1, -1), 0.6, GRID),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    story += [t2, Spacer(1, 12)]
    nb = ParagraphStyle("nb", fontName="Helvetica-Bold", fontSize=12, textColor=colors.white)
    nbr = ParagraphStyle("nbr", fontName="Helvetica-Bold", fontSize=16, textColor=colors.white, alignment=2)
    net = Table([[Paragraph("NET TAKE-HOME SALARY", nb), Paragraph(_txt(_pm(pay["net"], cur)), nbr)]],
                colWidths=[W * 0.55, W * 0.45])
    net.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PINK), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                             ("TOPPADDING", (0, 0), (-1, -1), 10), ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                             ("LEFTPADDING", (0, 0), (-1, -1), 12), ("RIGHTPADDING", (0, 0), (-1, -1), 12)]))
    story += [net, Spacer(1, 14)]
    fs = ParagraphStyle("fs", fontName="Helvetica-Oblique", fontSize=8, textColor=colors.grey, alignment=1)
    story.append(Paragraph(f"Status: {_txt(pay.get('status', ''))}. This is a computer-generated payslip and does not "
                           f"require a signature. Generated on {datetime.now():%d %b %Y %H:%M}.", fs))
    doc.build(story)
    return buf.getvalue()


def payslips_zip(company, items, month):
    """items: list of (emp_dict, pay_dict). Returns ZIP bytes with one PDF per employee."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for emp, pay in items:
            z.writestr(f"payslip_{emp['emp_id']}_{month}.pdf", payslip_pdf(company, emp, pay, month))
    return buf.getvalue()


def report_pdf(title, df, company, subtitle="", summary=None, money_cols=()):
    """Generic landscape table report. summary: list of (label, value) shown as header boxes."""
    cur = company.get("currency", "₹")
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=10 * mm, rightMargin=10 * mm,
                            topMargin=12 * mm, bottomMargin=12 * mm, title=title)
    W = landscape(A4)[0] - 20 * mm
    h1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=16, textColor=PURPLE)
    sm = ParagraphStyle("sm", fontName="Helvetica", fontSize=8.5, textColor=colors.grey)
    story = [Paragraph(_txt(company.get("company_name", "")), h1),
             Paragraph(_txt(f"{title}" + (f" - {subtitle}" if subtitle else "")), ParagraphStyle(
                 "h2", fontName="Helvetica-Bold", fontSize=11, textColor=PINK, spaceAfter=2)),
             Paragraph(f"Generated on {datetime.now():%d %b %Y %H:%M}", sm), Spacer(1, 6)]
    if summary:
        lab = ParagraphStyle("sl", fontName="Helvetica", fontSize=8, textColor=colors.white)
        vl = ParagraphStyle("sv", fontName="Helvetica-Bold", fontSize=12, textColor=colors.white)
        cells = [[[Paragraph(_txt(a), lab), Paragraph(_txt(b), vl)] for a, b in summary]]
        st_tbl = Table(cells, colWidths=[W / len(summary)] * len(summary))
        st_tbl.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PURPLE), ("LINEAFTER", (0, 0), (-2, -1), 3, colors.white),
                                    ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        story += [st_tbl, Spacer(1, 8)]
    if df is None or df.empty:
        story.append(Paragraph("No records found for the selected filters.", sm))
    else:
        fsz = 8 if len(df.columns) <= 9 else 6.5 if len(df.columns) <= 14 else 5.5
        hs = ParagraphStyle("th", fontName="Helvetica-Bold", fontSize=fsz, textColor=colors.white, leading=fsz + 2)
        cs = ParagraphStyle("td", fontName="Helvetica", fontSize=fsz, leading=fsz + 2)
        data = [[Paragraph(_txt(c), hs) for c in df.columns]]
        for _, r in df.iterrows():
            row = []
            for c in df.columns:
                v = r[c]
                if pd.isna(v):
                    v = ""
                elif c in money_cols:
                    v = _pm(v, cur)
                elif isinstance(v, float):
                    v = f"{v:,.2f}"
                row.append(Paragraph(_txt(v), cs))
            data.append(row)
        lens = [max([len(str(c))] + [len(str(x)) for x in df[c].head(60)]) for c in df.columns]
        lens = [min(max(l, 5), 28) for l in lens]
        widths = [W * l / sum(lens) for l in lens]
        tb = Table(data, colWidths=widths, repeatRows=1)
        tb.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), PURPLE), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
                                ("GRID", (0, 0), (-1, -1), 0.3, GRID), ("TOPPADDING", (0, 0), (-1, -1), 3),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        story.append(tb)

    def footer(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.grey)
        canvas.drawRightString(landscape(A4)[0] - 10 * mm, 6 * mm, f"Page {doc_.page}")
        canvas.drawString(10 * mm, 6 * mm, _txt(company.get("company_name", "")).replace("&amp;", "&"))
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()
