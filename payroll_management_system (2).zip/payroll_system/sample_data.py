"""sample_data.py - demo data so the app looks complete on first launch.

Demo logins (change them after first login!):
    admin / admin123      (role: Admin)
    hr    / hr123456      (role: HR)
"""
import random
from datetime import date, datetime, timedelta

import database as db
import payroll as pr
from utils import hash_password

DEPARTMENTS = ["Engineering", "Human Resources", "Finance", "Marketing", "Sales", "Operations", "Customer Support"]
DESIGNATIONS = {
    "Engineering": ["Software Engineer", "Senior Engineer", "QA Engineer", "Tech Lead"],
    "Human Resources": ["HR Executive", "HR Manager"],
    "Finance": ["Accountant", "Finance Manager"],
    "Marketing": ["Marketing Executive", "Content Strategist"],
    "Sales": ["Sales Executive", "Sales Manager"],
    "Operations": ["Operations Analyst", "Operations Manager"],
    "Customer Support": ["Support Associate", "Support Lead"],
}
NAMES = [
    ("Aarav Sharma", "M"), ("Priya Reddy", "F"), ("Rohan Kumar", "M"), ("Sneha Patel", "F"), ("Vikram Singh", "M"),
    ("Ananya Iyer", "F"), ("Kiran Rao", "M"), ("Meera Nair", "F"), ("Arjun Mehta", "M"), ("Divya Chowdary", "F"),
    ("Suresh Babu", "M"), ("Lakshmi Prasad", "F"), ("Rahul Verma", "M"), ("Pooja Gupta", "F"), ("Naveen Kumar", "M"),
    ("Swathi Yadav", "F"), ("Harish Naidu", "M"), ("Kavya Menon", "F"), ("Imran Khan", "M"), ("Neha Joshi", "F"),
    ("Sanjay Das", "M"), ("Tejaswi Varma", "F"),
]


def create_default_users():
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for u, name, role, pw in [("admin", "System Administrator", "admin", "admin123"),
                              ("hr", "HR Manager", "hr", "hr123456")]:
        if not db.one("SELECT 1 FROM users WHERE username=?", (u,)):
            db.run("INSERT INTO users(username,password_hash,full_name,role,created_at) VALUES(?,?,?,?,?)",
                   (u, hash_password(pw), name, role, now))


def _add_months(d, n):
    y, m = d.year, d.month + n
    while m <= 0:
        m += 12
        y -= 1
    while m > 12:
        m -= 12
        y += 1
    return date(y, m, 1)


def seed():
    rnd = random.Random(42)
    today = date.today()
    create_default_users()
    s = db.get_settings()

    # ---- employees ------------------------------------------------------- #
    emps = []
    bday_offsets = [2, 6, 11, 19, 27]  # guarantees upcoming birthdays on the dashboard
    for i, (name, _g) in enumerate(NAMES, start=1):
        dept = DEPARTMENTS[(i - 1) % len(DEPARTMENTS)]
        desig = rnd.choice(DESIGNATIONS[dept])
        base = {"Manager": 95000, "Lead": 90000, "Senior": 80000, "Tech": 90000}
        basic = next((v for k, v in base.items() if k in desig), rnd.choice([28000, 32000, 36000, 42000, 48000, 55000, 62000]))
        join = date(rnd.randint(2016, 2025), rnd.randint(1, 12), rnd.randint(1, 28))
        if join > today - timedelta(days=200):
            join = today - timedelta(days=rnd.randint(250, 900))
        if i - 1 < len(bday_offsets):
            b = today + timedelta(days=bday_offsets[i - 1])
            dob = date(rnd.randint(1985, 2000), b.month, b.day)
        else:
            dob = date(rnd.randint(1982, 2001), rnd.randint(1, 12), rnd.randint(1, 28))
        status = "Active"
        if i == len(NAMES) - 1:
            status = "On Leave"
        if i == len(NAMES):
            status = "Inactive"
        first = name.split()[0].lower()
        emps.append((f"EMP{i:03d}", name, f"{first}.{name.split()[1].lower()}@samplecompany.com",
                     f"98{rnd.randint(10000000, 99999999)}", f"{rnd.randint(1, 99)}, Lake View Road, Hyderabad",
                     dept, desig, join.isoformat(), dob.isoformat(), float(basic), 2000.0, status,
                     f"XXXXXX{rnd.randint(1000, 9999)}", None))
    db.run_many("INSERT INTO employees(emp_id,name,email,phone,address,department,designation,joining_date,dob,"
                "basic_salary,fixed_allowance,status,bank_account,photo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", emps)

    # salary revisions + promotions for a few employees
    for eid, name, *_rest in emps[:6]:
        row = db.one("SELECT basic_salary, designation, department FROM employees WHERE emp_id=?", (eid,))
        old = round(row["basic_salary"] * 0.9, -2)
        db.run("INSERT INTO salary_revisions(emp_id,old_salary,new_salary,effective_date,reason,created_by) VALUES(?,?,?,?,?,?)",
               (eid, old, row["basic_salary"], (today - timedelta(days=rnd.randint(120, 400))).isoformat(),
                "Annual appraisal", "admin"))
    for eid in ["EMP001", "EMP003", "EMP007"]:
        row = db.one("SELECT designation, department FROM employees WHERE emp_id=?", (eid,))
        db.run("INSERT INTO promotions(emp_id,old_designation,new_designation,old_department,new_department,"
               "effective_date,remarks) VALUES(?,?,?,?,?,?,?)",
               (eid, "Associate " + row["designation"], row["designation"], row["department"], row["department"],
                (today - timedelta(days=rnd.randint(150, 500))).isoformat(), "Promoted after excellent performance"))

    # ---- holidays -------------------------------------------------------- #
    hol = [(date(today.year, 1, 1), "New Year's Day", "National"), (date(today.year, 1, 14), "Sankranti / Pongal", "Company"),
           (date(today.year, 1, 26), "Republic Day", "National"), (date(today.year, 8, 15), "Independence Day", "National"),
           (date(today.year, 10, 2), "Gandhi Jayanti", "National"), (date(today.year, 12, 25), "Christmas", "National"),
           (date(today.year, 5, 1), "May Day", "Company"), (date(today.year, 9, 5), "Company Annual Day", "Company")]
    db.run_many("INSERT OR IGNORE INTO holidays(date,name,kind) VALUES(?,?,?)", [(d.isoformat(), n, k) for d, n, k in hol])
    hol_set = {d for d, _, _ in hol}

    # ---- attendance: last 6 months through yesterday ---------------------- #
    start = _add_months(today.replace(day=1), -5)
    att = []
    working = [e for e in emps if e[11] != "Inactive"]
    d = start
    while d < today:
        if d.weekday() != 6:
            for e in working:
                if d in hol_set:
                    att.append((e[0], d.isoformat(), "Holiday", None, None))
                    continue
                st_ = rnd.choices(["Present", "Work From Home", "Half Day", "Absent", "Leave"], [87, 6, 3, 2, 2])[0]
                ci = co = None
                if st_ in ("Present", "Work From Home"):
                    ci = f"09:{rnd.randint(0, 45):02d}"
                    co = f"{rnd.randint(17, 19)}:{rnd.randint(0, 59):02d}"
                elif st_ == "Half Day":
                    ci, co = "09:30", "13:30"
                att.append((e[0], d.isoformat(), st_, ci, co))
        d += timedelta(days=1)
    db.run_many("INSERT OR IGNORE INTO attendance(emp_id,date,status,check_in,check_out) VALUES(?,?,?,?,?)", att)

    # ---- loans ----------------------------------------------------------- #
    for eid, typ, amt, emi in [("EMP003", "Loan", 120000, 10000), ("EMP008", "Salary Advance", 20000, 5000),
                               ("EMP012", "Loan", 60000, 5000)]:
        db.run("INSERT INTO loans(emp_id,loan_type,amount,monthly_deduction,balance,start_date,status,notes) "
               "VALUES(?,?,?,?,?,?,'Active',?)", (eid, typ, amt, emi, amt, start.isoformat(), "Sample record"))

    # ---- payroll history (real pipeline: LOP, overtime, loans, tax) ------- #
    active_ids = [e[0] for e in emps if e[11] in ("Active", "On Leave")]
    for back in range(5, 0, -1):
        m = _add_months(today.replace(day=1), -back).strftime("%Y-%m")
        inputs = {eid: {"bonus": float(rnd.choice([0, 0, 0, 2000, 5000])) if back > 1 else 0.0} for eid in active_ids}
        created, _ = pr.process_payroll(active_ids, m, inputs, "hr", s)
        rows = db.q("SELECT id FROM payroll WHERE month=? ORDER BY id", (m,)).id.tolist()
        if back > 1:
            pr.approve_payroll(rows, "admin")
            pr.mark_paid(rows)
        else:  # last month: partly approved, partly pending - shows the approval workflow
            pr.approve_payroll(rows[:14], "admin")

    # ---- leave requests -------------------------------------------------- #
    types = ["Casual Leave", "Sick Leave", "Earned Leave"]
    reasons = ["Family function", "Fever and rest", "Personal work", "Travel", "Medical appointment", "Festival"]
    statuses = ["Approved"] * 6 + ["Pending"] * 4 + ["Rejected"] * 2
    for i, stt in enumerate(statuses):
        eid = working[(i * 2) % len(working)][0]
        a = today + timedelta(days=rnd.randint(-40, 20))
        b = a + timedelta(days=rnd.randint(0, 2))
        days = pr.leave_days(a, b)
        if days == 0:
            continue
        db.run("INSERT INTO leaves(emp_id,leave_type,start_date,end_date,days,reason,status,applied_on,decided_by,decided_on) "
               "VALUES(?,?,?,?,?,?,?,?,?,?)",
               (eid, types[i % 3], a.isoformat(), b.isoformat(), days, rnd.choice(reasons), stt,
                (a - timedelta(days=3)).isoformat(), None if stt == "Pending" else "hr",
                None if stt == "Pending" else (a - timedelta(days=2)).isoformat()))

    # ---- reimbursements -------------------------------------------------- #
    for eid, cat, amt, stt in [("EMP002", "Travel", 3200, "Pending"), ("EMP005", "Internet", 1200, "Pending"),
                               ("EMP009", "Medical", 4500, "Approved"), ("EMP011", "Travel", 2100, "Rejected"),
                               ("EMP014", "Training Material", 1800, "Pending")]:
        db.run("INSERT INTO reimbursements(emp_id,category,amount,claim_date,description,status,decided_by) VALUES(?,?,?,?,?,?,?)",
               (eid, cat, amt, (today - timedelta(days=rnd.randint(1, 15))).isoformat(), f"{cat} expense claim", stt,
                None if stt == "Pending" else "hr"))

    # ---- performance reviews, training, documents ------------------------ #
    period = f"{today.year} H1"
    for e in working:
        db.run("INSERT INTO reviews(emp_id,period,rating,reviewer,strengths,improvements,comments,review_date) VALUES(?,?,?,?,?,?,?,?)",
               (e[0], period, rnd.choice([3.0, 3.5, 4.0, 4.0, 4.5, 5.0]), "HR Manager", "Teamwork, ownership",
                "Time management", "Consistent performer", (today - timedelta(days=rnd.randint(20, 120))).isoformat()))
    trainings = [("Advanced Excel", "Internal", "Training"), ("Leadership Essentials", "Coursera", "Certification"),
                 ("Workplace Safety", "Internal", "Training"), ("AWS Cloud Practitioner", "Amazon", "Certification"),
                 ("Data Privacy Basics", "Internal", "Training"), ("PMP Prep", "PMI", "Certification")]
    for i, (title, prov, kind) in enumerate(trainings * 2):
        e = working[(i * 3) % len(working)]
        s0 = today - timedelta(days=rnd.randint(10, 200))
        stat = rnd.choice(["Completed", "Completed", "In Progress", "Planned"])
        exp = (today + timedelta(days=rnd.randint(-20, 400))).isoformat() if kind == "Certification" else None
        db.run("INSERT INTO trainings(emp_id,title,provider,kind,start_date,end_date,status,certificate_expiry,notes) "
               "VALUES(?,?,?,?,?,?,?,?,?)", (e[0], title, prov, kind, s0.isoformat(), (s0 + timedelta(days=5)).isoformat(),
                                             stat, exp, ""))
    doc_types = ["Passport", "Driving License", "Work Permit", "ID Proof", "Medical Certificate"]
    offsets = [-15, 9, 21, 28, 45, 58, 90, 200, 400, 700]
    for i, e in enumerate(working):
        for k in range(2):
            off = offsets[(i * 2 + k) % len(offsets)]
            db.run("INSERT INTO documents(emp_id,doc_type,doc_number,issue_date,expiry_date,notes) VALUES(?,?,?,?,?,?)",
                   (e[0], doc_types[(i + k) % len(doc_types)], f"DOC{rnd.randint(100000, 999999)}",
                    (today - timedelta(days=700)).isoformat(), (today + timedelta(days=off)).isoformat(), ""))

    # ---- resignation (settled, for the inactive employee) ----------------- #
    last = emps[-1][0]
    lwd = today - timedelta(days=40)
    calc = pr.calc_settlement(last, lwd, 30, 30, s)
    db.run("INSERT INTO resignations(emp_id,resign_date,last_working_date,reason,notice_required,notice_served,pending_salary,"
           "leave_encashment,gratuity,reimbursements,notice_recovery,loan_recovery,net_settlement,status,settled_on) "
           "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'Settled',?)",
           (last, (lwd - timedelta(days=30)).isoformat(), lwd.isoformat(), "Higher studies", 30, 30,
            calc["pending_salary"], calc["leave_encashment"], calc["gratuity"], calc["reimbursements"],
            calc["notice_recovery"], calc["loan_recovery"], calc["net_settlement"], (lwd + timedelta(days=5)).isoformat()))

    # ---- audit log sample ------------------------------------------------ #
    acts = [("admin", "LOGIN", "Signed in"), ("hr", "ADD_EMPLOYEE", "Added employee EMP020"),
            ("hr", "PROCESS_PAYROLL", "Processed payroll for last month"), ("admin", "APPROVE_PAYROLL", "Approved 14 payroll entries"),
            ("hr", "APPROVE_LEAVE", "Approved leave request"), ("admin", "UPDATE_SETTINGS", "Updated payroll settings"),
            ("hr", "ADD_REIMBURSEMENT", "Reimbursement claim recorded"), ("hr", "MARK_ATTENDANCE", "Attendance saved")]
    now = datetime.now()
    for i, (u, a, dtl) in enumerate(acts):
        db.run("INSERT INTO audit_logs(ts,username,action,details) VALUES(?,?,?,?)",
               ((now - timedelta(hours=3 * (len(acts) - i))).strftime("%Y-%m-%d %H:%M:%S"), u, a, dtl))
