# 💼 PayrollPro - Employee Payroll Management System

A colourful, modern HR & payroll dashboard built with **Python + Streamlit**, **SQLite**, **Pandas**, **Plotly** and **ReportLab**.
Purple / pink / blue gradient theme, gradient sidebar with an icon for every page, KPI cards, interactive charts, PDF payslips,
role-based access, audit logs, backup & restore, light/dark theme and English / Telugu / Hindi.

On the first launch the app creates its database and fills it with **sample data** (22 employees, 6 months of attendance,
5 months of payroll, leave requests, loans, reviews, documents ...) so the dashboard looks complete straight away.

---

## 1. Run it on your computer

You need **Python 3.10 - 3.12** (3.11 or 3.12 recommended).

```bash
# 1) open a terminal in this folder
python -m venv .venv

# 2) activate it
#    Windows:   .venv\Scripts\activate
#    Mac/Linux: source .venv/bin/activate

# 3) install the libraries
pip install -r requirements.txt

# 4) start the app
streamlit run app.py
```

Your browser opens at <http://localhost:8501>.

### Demo logins (change them after your first login!)

| Role  | Username | Password   | Can do |
|-------|----------|------------|--------|
| Admin | `admin`  | `admin123` | everything |
| HR    | `hr`     | `hr123456` | employees, process payroll, attendance, leaves, HR extras, reports. **Cannot** approve payroll, delete employees, complete settlements, change company/payroll settings, manage users, back up/restore or view audit logs |

Change a password in **Settings → My Account**. Admins can add users in **Settings → Users & Roles**.

**Starting with an empty system (no sample data)?** Set the environment variable `PAYROLL_SEED_SAMPLE=0` before the very first launch
(on Streamlit Cloud: *Settings → Secrets / Environment*). Only the `admin` / `hr` users are created. To start over locally, delete `payroll.db`.

---

## 2. What is inside

| File | Purpose |
|------|---------|
| `app.py` | The Streamlit user interface - all 16 pages, login, sidebar, theme, language |
| `database.py` | SQLite schema, helper functions, settings, backup & restore |
| `payroll.py` | Salary maths (HRA, DA, PF, tax slabs, overtime, LOP), attendance rules, leave balances, payroll workflow, final settlement |
| `utils.py` | Password hashing, permissions, translations, CSS, HTML tables/KPI cards, PDF payslips and reports |
| `sample_data.py` | Demo data seeding |
| `requirements.txt` | Python dependencies |
| `.streamlit/config.toml` | Purple theme colours |

### Pages (all in the sidebar)

Dashboard · Employees · Payroll · Payslips · Attendance · Leave Management · Performance Reviews · Training & Certifications ·
Holiday Calendar · Document Expiry · Loans & Advances · Reimbursements · Resignation & Settlement · Reports & Analytics ·
Audit Logs (admin) · Settings

### How salary is calculated

* **Gross** = Basic + HRA (% of basic) + DA (% of basic) + fixed allowance + bonus + overtime + approved reimbursements
* **Overtime** = hours × (basic ÷ paying days ÷ standard hours) × multiplier. Hours can be pre-filled from attendance check-in/out times.
* **Loss of pay (LOP)** = absent days not covered by approved paid leave + unpaid-leave days + ½ per half-day, × (basic ÷ paying days)
* **Deductions** = PF + income tax (3 configurable monthly slabs) + professional tax + loan EMI + salary-advance recovery + LOP + other
* **Net take-home** = Gross − Total deductions
* Every percentage, slab and rule is editable in **Settings → Payroll Settings**.
* A **unique (employee, month)** rule in the database blocks duplicate payroll entries.
* **Workflow:** *Pending Approval* → (Admin) *Approved* → (Admin) *Paid*. Loan balances reduce when payroll is approved.

> The default tax slabs, PF rate, professional tax and gratuity formula are **illustrative defaults**, not tax or legal advice.
> Check them against the rules that apply to your company before using real payroll.

---

## 3. Put the project on GitHub (beginner steps)

**Option A - no command line (easiest)**
1. Create a free account at <https://github.com> and click **New repository**.
2. Name it (e.g. `payroll-system`), choose **Public** (Streamlit Community Cloud free tier needs public repos, or connect a private one when you grant access), click **Create repository**.
3. Click **uploading an existing file**, drag in *all files from this folder* (`app.py`, `database.py`, `payroll.py`, `utils.py`, `sample_data.py`,
   `requirements.txt`, `README.md`, `.gitignore`) **and the `.streamlit` folder** (drag the folder itself, or use *Add file → Create new file* and type
   `.streamlit/config.toml`).
4. Click **Commit changes**.

**Option B - command line**
```bash
git init
git add .
git commit -m "Initial commit - PayrollPro"
git branch -M main
git remote add origin https://github.com/<your-username>/payroll-system.git
git push -u origin main
```

> ⚠️ Never upload a `payroll.db` that contains real employee data - the included `.gitignore` already excludes it.

---

## 4. Deploy online with Streamlit Community Cloud (free shareable link)

1. Go to <https://share.streamlit.io> and sign in with your GitHub account.
2. Click **Create app** → **Deploy a public app from GitHub**.
3. Pick your repository, branch `main`, and set **Main file path** to `app.py`.
4. Open **Advanced settings** and choose **Python 3.11 or 3.12**.
5. Click **Deploy**. After a minute or two you get a link like `https://your-app-name.streamlit.app` that you can share.
6. Sign in with `admin / admin123` and **change the passwords immediately** because the demo logins are public knowledge.

Updating the app later: edit files on GitHub (or `git push`) and Streamlit Cloud redeploys automatically.

---

## 5. ⚠️ Database persistence & backups - please read

The app stores everything in a single SQLite file (`payroll.db`) next to `app.py`.

* **Locally** the file is permanent - just back it up occasionally.
* **On Streamlit Community Cloud the disk is ephemeral.** Data you enter survives normal use, but the file is **lost/reset** when the app is
  rebooted, redeployed (every `git push`), or put to sleep after inactivity and rebuilt. When that happens the app starts again with fresh sample data.
* **What to do:**
  1. Use **Settings → Backup & Restore → Download database backup** regularly (it contains employees, photos, payroll, users, settings ...).
  2. After a reset, log in with the demo admin and use **Restore** to upload your last backup.
  3. For *real, long-term production use*, host the app somewhere with a persistent disk (a small VPS, Docker volume, Render/Railway disk, etc.)
     or replace SQLite with a hosted database (see below).
* Treat the free Cloud deployment as a **demo / prototype**. Do not rely on it as the only copy of real HR data, and remember that
  payroll data is sensitive: use a private repository and strong passwords.

---

## 6. Features that need extra configuration or external services

| Item | Status |
|------|--------|
| Running locally and on Streamlit Cloud | ✅ No external service, API key or secret is required |
| Permanent storage on Streamlit Cloud | ❌ Not included. Needs an external hosted database (PostgreSQL/MySQL/Turso/Supabase) and changes to `database.py`, or a host with a persistent disk |
| Email / SMS notifications (payslip emailing, expiry e-mails) | ❌ Not included - needs an SMTP / e-mail service. Reminders are shown in the app (dashboard alerts and Document Expiry page) |
| Biometric / GPS attendance devices | ❌ Not included. Attendance is entered manually in the app |
| Bank payment files / statutory filings (PF/ESI/TDS returns) | ❌ Not included |
| Telugu / Hindi **inside PDFs** | ⚠️ The built-in PDF fonts are Latin only; non-Latin characters in names show as `?`. To support them, register a Unicode TTF font (e.g. Noto Sans Telugu/Devanagari) in `utils.py` with ReportLab's `TTFont` |
| Telugu / Hindi UI text | ⚠️ Navigation, headings, KPI labels and key buttons are translated. Long help text, form labels and messages stay in English. Add more keys to the `TR` dictionary in `utils.py` to translate more |
| Dark theme | ⚠️ Implemented with custom CSS. Streamlit's own table/grid widgets (data editors) may keep light colours |

---

## 7. Troubleshooting

* **`ModuleNotFoundError`** - run `pip install -r requirements.txt` inside your activated virtual environment.
* **Reset everything locally** - stop the app, delete `payroll.db`, start again.
* **Photos / uploads** - PNG or JPG; photos are resized to 256 px and stored inside the database (so they are included in backups).
* **Forgot the admin password** - delete `payroll.db` (this erases data) or restore a backup; there is intentionally no e-mail reset.
* **Time entry** - attendance check-in/out use 24-hour `HH:MM` (e.g. `09:30`, `18:15`).
