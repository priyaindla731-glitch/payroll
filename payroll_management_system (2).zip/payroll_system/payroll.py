"""payroll.py - salary calculation, attendance rules, leave balances, payroll workflow."""
import calendar
import sqlite3
from datetime import date, datetime, timedelta

import database as db

LEAVE_TYPES = ["Casual Leave", "Sick Leave", "Earned Leave", "Unpaid Leave"]
QUOTA_KEYS = {"Casual Leave": "quota_casual", "Sick Leave": "quota_sick", "Earned Leave": "quota_earned"}


def fnum(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


# --------------------------------------------------------------------------- #
# Pure salary maths
# --------------------------------------------------------------------------- #
def monthly_tax(taxable, s):
    """Marginal monthly tax using three configurable slabs."""
    l1, l2 = fnum(s.get("tax_slab1_limit")), fnum(s.get("tax_slab2_limit"))
    p2, p3 = fnum(s.get("tax_slab2_pct")), fnum(s.get("tax_slab3_pct"))
    tax = 0.0
    if taxable > l1:
        tax += (min(taxable, l2) - l1) * p2 / 100.0
    if taxable > l2:
        tax += (taxable - l2) * p3 / 100.0
    return max(tax, 0.0)


def calc_payroll(basic, s, *, allowances=0.0, bonus=0.0, overtime_hours=0.0, reimbursements=0.0,
                 lop_days=0.0, loan_ded=0.0, advance_ded=0.0, other_ded=0.0, pf_applicable=True):
    """Return a dict with every earning/deduction line plus gross, total_ded and net."""
    wd = max(fnum(s.get("working_days"), 26), 1)
    hrs = max(fnum(s.get("hours_per_day"), 9), 1)
    basic = fnum(basic)
    hra = basic * fnum(s.get("hra_pct")) / 100
    da = basic * fnum(s.get("da_pct")) / 100
    per_day = basic / wd
    overtime = fnum(overtime_hours) * (per_day / hrs) * fnum(s.get("overtime_multiplier"), 1.5)
    gross = basic + hra + da + allowances + bonus + overtime + reimbursements
    lop_amount = per_day * lop_days
    taxable = max(0.0, gross - reimbursements - lop_amount)
    pf_wage = basic + da
    cap = fnum(s.get("pf_wage_cap"))
    if cap > 0:
        pf_wage = min(pf_wage, cap)
    pf = pf_wage * fnum(s.get("pf_rate")) / 100 if pf_applicable else 0.0
    tax = monthly_tax(taxable, s)
    ptax = fnum(s.get("prof_tax")) if taxable >= fnum(s.get("prof_tax_threshold")) else 0.0
    total_ded = pf + tax + ptax + loan_ded + advance_ded + lop_amount + other_ded
    out = dict(basic=basic, hra=hra, da=da, allowances=allowances, bonus=bonus, overtime=overtime,
               reimbursements=reimbursements, gross=gross, pf=pf, tax=tax, prof_tax=ptax,
               loan_ded=loan_ded, advance_ded=advance_ded, lop_days=lop_days, lop_amount=lop_amount,
               other_ded=other_ded, total_ded=total_ded, net=gross - total_ded)
    return {k: round(v, 2) for k, v in out.items()}


# --------------------------------------------------------------------------- #
# Dates / attendance
# --------------------------------------------------------------------------- #
def month_bounds(month):
    y, m = map(int, month.split("-"))
    return date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1])


def daterange(a, b):
    d = a
    while d <= b:
        yield d
        d += timedelta(days=1)


def leave_days(start, end):
    """Calendar days between two dates, inclusive, excluding Sundays."""
    return float(sum(1 for d in daterange(start, end) if d.weekday() != 6))


def parse_hhmm(txt):
    try:
        return datetime.strptime(str(txt).strip(), "%H:%M")
    except (ValueError, TypeError):
        return None


def worked_hours(check_in, check_out):
    a, b = parse_hhmm(check_in), parse_hhmm(check_out)
    if a and b and b > a:
        return (b - a).seconds / 3600.0
    return 0.0


def attendance_summary(emp_id, month, s=None):
    """Summarise a month of attendance and work out loss-of-pay days."""
    s = s or db.get_settings()
    first, last = month_bounds(month)
    att = db.q("SELECT date,status,check_in,check_out FROM attendance "
               "WHERE emp_id=? AND date BETWEEN ? AND ?", (emp_id, first.isoformat(), last.isoformat()))
    lv = db.q("SELECT leave_type,start_date,end_date FROM leaves WHERE emp_id=? AND status='Approved' "
              "AND start_date<=? AND end_date>=?", (emp_id, last.isoformat(), first.isoformat()))
    paid, unpaid = set(), set()
    for r in lv.itertuples():
        a = max(date.fromisoformat(r.start_date), first)
        b = min(date.fromisoformat(r.end_date), last)
        for d in daterange(a, b):
            if d.weekday() != 6:
                (unpaid if r.leave_type == "Unpaid Leave" else paid).add(d)
    counts = att.status.value_counts().to_dict() if not att.empty else {}
    absent_dates = {date.fromisoformat(x) for x in att.loc[att.status == "Absent", "date"]}
    half = counts.get("Half Day", 0)
    lop_days = len((absent_dates - paid) | unpaid) + 0.5 * half
    present, wfh, absent = counts.get("Present", 0), counts.get("Work From Home", 0), counts.get("Absent", 0)
    denom = present + wfh + half + absent
    pct = round((present + wfh + 0.5 * half) / denom * 100, 1) if denom else 0.0
    hrs_std = fnum(s.get("hours_per_day"), 9)
    ot = wk = 0.0
    for r in att.itertuples():
        if r.status in ("Present", "Work From Home"):
            h = worked_hours(r.check_in, r.check_out)
            wk += h
            ot += max(0.0, h - hrs_std) if h else 0.0
    return dict(present=present, absent=absent, half_day=half, wfh=wfh,
                holiday=counts.get("Holiday", 0), leave=counts.get("Leave", 0),
                records=len(att), lop_days=float(lop_days), ot_hours=round(ot, 2),
                worked_hours=round(wk, 1), attendance_pct=pct)


# --------------------------------------------------------------------------- #
# Leave balances
# --------------------------------------------------------------------------- #
def leave_balance(emp_id, year, s=None):
    """Rows of dicts: leave type, quota, used (approved), pending, balance."""
    s = s or db.get_settings()
    rows = []
    for lt in LEAVE_TYPES:
        used = db.scalar("SELECT COALESCE(SUM(days),0) FROM leaves WHERE emp_id=? AND leave_type=? "
                         "AND status='Approved' AND substr(start_date,1,4)=?", (emp_id, lt, str(year)))
        pend = db.scalar("SELECT COALESCE(SUM(days),0) FROM leaves WHERE emp_id=? AND leave_type=? "
                         "AND status='Pending' AND substr(start_date,1,4)=?", (emp_id, lt, str(year)))
        if lt in QUOTA_KEYS:
            quota = fnum(s.get(QUOTA_KEYS[lt]))
            bal = quota - used
        else:
            quota, bal = None, None
        rows.append(dict(leave_type=lt, quota=quota, used=used, pending=pend, balance=bal))
    return rows


# --------------------------------------------------------------------------- #
# Loans, reimbursements and the payroll workflow
# --------------------------------------------------------------------------- #
def loan_deductions(emp_id):
    lo = db.q("SELECT loan_type,balance,monthly_deduction FROM loans WHERE emp_id=? AND status='Active'", (emp_id,))
    loan = adv = 0.0
    for r in lo.itertuples():
        d = min(r.balance, r.monthly_deduction)
        if r.loan_type == "Salary Advance":
            adv += d
        else:
            loan += d
    return loan, adv


def pending_reimbursements(emp_id):
    return float(db.scalar("SELECT COALESCE(SUM(amount),0) FROM reimbursements WHERE emp_id=? "
                           "AND status='Approved' AND (payroll_month IS NULL OR payroll_month='')", (emp_id,)))


def compute_for_employee(emp_id, month, s, bonus=0.0, overtime_hours=None, other_ded=0.0):
    """Full payroll calculation for one employee-month (does not save anything)."""
    emp = db.one("SELECT basic_salary, fixed_allowance FROM employees WHERE emp_id=?", (emp_id,))
    summ = attendance_summary(emp_id, month, s)
    if overtime_hours is None:
        overtime_hours = summ["ot_hours"] if s.get("ot_from_attendance") == "1" else 0.0
    lop = summ["lop_days"] if s.get("apply_lop") == "1" else 0.0
    loan, adv = loan_deductions(emp_id)
    return calc_payroll(emp["basic_salary"], s, allowances=emp["fixed_allowance"] or 0.0,
                        bonus=bonus, overtime_hours=overtime_hours,
                        reimbursements=pending_reimbursements(emp_id), lop_days=lop,
                        loan_ded=loan, advance_ded=adv, other_ded=other_ded)


PAY_COLS = ["basic", "hra", "da", "allowances", "bonus", "overtime", "reimbursements", "gross", "pf", "tax",
            "prof_tax", "loan_ded", "advance_ded", "lop_days", "lop_amount", "other_ded", "total_ded", "net"]


def process_payroll(emp_ids, month, inputs, user, s=None):
    """Create payroll rows. Returns (created_ids, skipped_ids). Duplicates (employee+month) are skipped."""
    s = s or db.get_settings()
    created, skipped = [], []
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for eid in emp_ids:
        if db.one("SELECT 1 FROM payroll WHERE emp_id=? AND month=?", (eid, month)):
            skipped.append(eid)
            continue
        inp = inputs.get(eid, {})
        calc = compute_for_employee(eid, month, s, bonus=fnum(inp.get("bonus")),
                                    overtime_hours=inp.get("overtime_hours"), other_ded=fnum(inp.get("other_ded")))
        cols = ",".join(PAY_COLS)
        marks = ",".join("?" * len(PAY_COLS))
        try:
            db.run(f"INSERT INTO payroll(emp_id,month,{cols},status,processed_by,processed_at) "
                   f"VALUES(?,?,{marks},'Pending Approval',?,?)",
                   (eid, month, *[calc[c] for c in PAY_COLS], user, now))
        except sqlite3.IntegrityError:
            skipped.append(eid)
            continue
        db.run("UPDATE reimbursements SET payroll_month=? WHERE emp_id=? AND status='Approved' "
               "AND (payroll_month IS NULL OR payroll_month='')", (month, eid))
        created.append(eid)
    return created, skipped


def _apply_recovery(emp_id, kind, amount):
    """Reduce loan balances after an approved payroll deducted `amount`."""
    remaining = fnum(amount)
    if remaining <= 0:
        return
    cond = "loan_type='Salary Advance'" if kind == "Salary Advance" else "loan_type<>'Salary Advance'"
    lo = db.q(f"SELECT id,balance,monthly_deduction FROM loans WHERE emp_id=? AND status='Active' AND {cond} ORDER BY id",
              (emp_id,))
    for r in lo.itertuples():
        if remaining <= 0:
            break
        take = min(r.balance, r.monthly_deduction, remaining)
        newbal = round(r.balance - take, 2)
        db.run("UPDATE loans SET balance=?, status=? WHERE id=?",
               (newbal, "Closed" if newbal <= 0.01 else "Active", r.id))
        remaining -= take


def approve_payroll(ids, user):
    n = 0
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for pid in ids:
        row = db.one("SELECT * FROM payroll WHERE id=? AND status='Pending Approval'", (int(pid),))
        if not row:
            continue
        db.run("UPDATE payroll SET status='Approved', approved_by=?, approved_at=? WHERE id=?", (user, now, int(pid)))
        _apply_recovery(row["emp_id"], "Loan", row["loan_ded"])
        _apply_recovery(row["emp_id"], "Salary Advance", row["advance_ded"])
        n += 1
    return n


def reject_payroll(ids, user):
    n = 0
    for pid in ids:
        db.run("UPDATE payroll SET status='Rejected', approved_by=? WHERE id=? AND status='Pending Approval'",
               (user, int(pid)))
        n += 1
    return n


def mark_paid(ids):
    for pid in ids:
        db.run("UPDATE payroll SET status='Paid' WHERE id=? AND status='Approved'", (int(pid),))
    return len(ids)


def delete_payroll(ids):
    """Delete only Pending/Rejected rows so that they can be re-processed. Frees reimbursements."""
    n = 0
    for pid in ids:
        row = db.one("SELECT emp_id,month,status FROM payroll WHERE id=?", (int(pid),))
        if row and row["status"] in ("Pending Approval", "Rejected"):
            db.run("DELETE FROM payroll WHERE id=?", (int(pid),))
            db.run("UPDATE reimbursements SET payroll_month=NULL WHERE emp_id=? AND payroll_month=?",
                   (row["emp_id"], row["month"]))
            n += 1
    return n


# --------------------------------------------------------------------------- #
# Resignation / final settlement
# --------------------------------------------------------------------------- #
def calc_settlement(emp_id, last_working_date, notice_required, notice_served, s=None):
    s = s or db.get_settings()
    emp = db.one("SELECT * FROM employees WHERE emp_id=?", (emp_id,))
    wd = max(fnum(s.get("working_days"), 26), 1)
    basic = fnum(emp["basic_salary"])
    per_day = basic / wd
    month = last_working_date.strftime("%Y-%m")
    dim = calendar.monthrange(last_working_date.year, last_working_date.month)[1]
    fixed = basic * (1 + fnum(s.get("hra_pct")) / 100 + fnum(s.get("da_pct")) / 100) + fnum(emp["fixed_allowance"])
    already = db.one("SELECT 1 FROM payroll WHERE emp_id=? AND month=?", (emp_id, month))
    pending_salary = 0.0 if already else fixed * last_working_date.day / dim
    earned = next(r for r in leave_balance(emp_id, last_working_date.year, s) if r["leave_type"] == "Earned Leave")
    encash = per_day * max(0.0, earned["balance"] or 0.0)
    years = 0
    if emp["joining_date"]:
        years = int((last_working_date - date.fromisoformat(emp["joining_date"])).days // 365.25)
    gratuity = basic * 15 / 26 * years if years >= 5 else 0.0
    notice_recovery = per_day * max(0, int(notice_required) - int(notice_served))
    loan_recovery = float(db.scalar("SELECT COALESCE(SUM(balance),0) FROM loans WHERE emp_id=? AND status='Active'", (emp_id,)))
    reimb = pending_reimbursements(emp_id)
    net = pending_salary + encash + gratuity + reimb - notice_recovery - loan_recovery
    return {k: round(v, 2) for k, v in dict(
        pending_salary=pending_salary, leave_encashment=encash, gratuity=gratuity, reimbursements=reimb,
        notice_recovery=notice_recovery, loan_recovery=loan_recovery, net_settlement=net).items()}
