"""app.py - PayrollPro: Employee Payroll Management System (Streamlit).

Run with:  streamlit run app.py
"""
import io
import time
from datetime import date, datetime, timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="PayrollPro - Employee Payroll System", page_icon="💼", layout="wide",
                   initial_sidebar_state="expanded")

import database as db  # noqa: E402
import payroll as pr  # noqa: E402
import utils as U  # noqa: E402
from utils import t  # noqa: E402

PAGES = [("dashboard", "🏠"), ("employees", "👥"), ("payroll", "💰"), ("payslips", "🧾"), ("attendance", "🕒"),
         ("leaves", "🌴"), ("performance", "⭐"), ("training", "🎓"), ("holidays", "🎉"), ("documents", "📄"),
         ("loans", "🏦"), ("reimbursements", "💳"), ("resignations", "🚪"), ("reports", "📊"),
         ("audit", "🛡️"), ("settings", "⚙️")]
ICON = dict(PAGES)
DEPARTMENTS = ["Engineering", "Human Resources", "Finance", "Marketing", "Sales", "Operations", "Customer Support"]
EMP_STATUS = ["Active", "Inactive", "On Leave"]
ATT_STATUS = ["Present", "Absent", "Half Day", "Work From Home", "Holiday", "Leave"]
EMP_COLS = ("emp_id,name,email,phone,address,department,designation,joining_date,dob,basic_salary,"
            "fixed_allowance,status,bank_account")
S = {}  # settings for the current run (filled in main())


@st.cache_resource(show_spinner="Setting up the database...")
def boot():
    db.init_db()
    return True


# --------------------------------------------------------------------------- #
# Generic helpers
# --------------------------------------------------------------------------- #
def me():
    return st.session_state["user"]


def can(action):
    return U.can(me()["role"], action)


def audit(action, details=""):
    db.log_action(me()["username"], action, details)


def flash(msg, kind="success"):
    st.session_state["_flash"] = (msg, kind)


def show_flash():
    f = st.session_state.pop("_flash", None)
    if f:
        getattr(st, f[1])(f[0])


def goto(page):
    st.session_state["_goto"] = page


def cur():
    return S.get("currency", "₹")


def money(x):
    return U.money(x, cur())


def header(page, sub=""):
    st.markdown(U.page_header(ICON[page], t(page), sub), unsafe_allow_html=True)
    show_flash()


def table(df, badge_cols=(), money_cols=(), max_rows=200):
    st.markdown(U.html_table(df, badge_cols, max_rows, money_cols, cur()), unsafe_allow_html=True)


def csv_button(df, name, label="⬇️ Download CSV", key=None):
    st.download_button(label, df.to_csv(index=False).encode("utf-8"), file_name=name, mime="text/csv", key=key)


def employees(statuses=None):
    sql = f"SELECT {EMP_COLS} FROM employees"
    params = ()
    if statuses:
        sql += " WHERE status IN (%s)" % ",".join("?" * len(statuses))
        params = tuple(statuses)
    return db.q(sql + " ORDER BY emp_id", params)


def emp_select(label, key, statuses=None, allow_all=False):
    df = employees(statuses)
    labels = {r.emp_id: f"{r.emp_id} · {r.name}" for r in df.itertuples()}
    opts = (["__all__"] if allow_all else []) + list(labels)
    if not opts:
        st.info("No employees available yet. Add one in the Employees page.")
        return None
    pick = st.selectbox(label, opts, key=key, format_func=lambda k: "All employees" if k == "__all__" else labels[k])
    return pick


def delete_control(tbl, ids, label, key, allowed=True):
    """Select a record id and delete it (with confirmation)."""
    if not allowed or not len(ids):
        return
    with st.expander(f"🗑️ Delete a {label}"):
        rid = st.selectbox("Record ID", list(ids), key=f"{key}_id")
        ok = st.checkbox("I understand this cannot be undone", key=f"{key}_ok")
        if st.button("Delete record", key=f"{key}_btn", disabled=not ok):
            db.run(f"DELETE FROM {tbl} WHERE id=?", (int(rid),))
            audit(f"DELETE_{tbl.upper()}", f"Deleted {label} #{rid}")
            flash(f"{label.capitalize()} #{rid} deleted.")
            st.rerun()


def valid_hhmm(txt):
    return txt in (None, "", "None") or pr.parse_hhmm(txt) is not None


def plot(fig, height=360):
    st.plotly_chart(U.style_fig(fig, height))


# --------------------------------------------------------------------------- #
# Login
# --------------------------------------------------------------------------- #
def login_page():
    st.markdown(U.get_css(False), unsafe_allow_html=True)
    st.markdown("<style>[data-testid='stSidebar']{display:none}</style>", unsafe_allow_html=True)
    _, mid, _ = st.columns([1, 1.3, 1])
    with mid:
        show_flash()
        st.markdown(U.page_header("💼", "PayrollPro", "Employee Payroll Management System - please sign in"),
                    unsafe_allow_html=True)
        locked = st.session_state.get("locked_until", 0) - time.time()
        with st.form("login"):
            username = st.text_input(t("username"))
            password = st.text_input(t("password"), type="password")
            go_ = st.form_submit_button("🔐 " + t("sign_in"), disabled=locked > 0)
        if locked > 0:
            st.error(f"Too many failed attempts. Try again in {int(locked)} seconds.")
        if go_:
            row = db.one("SELECT * FROM users WHERE username=? AND active=1", (username.strip(),))
            if row and U.verify_password(password, row["password_hash"]):
                st.session_state["user"] = {k: row[k] for k in ("id", "username", "full_name", "role", "theme", "lang")}
                st.session_state["lang"] = row["lang"] or "en"
                st.session_state["dark"] = row["theme"] == "dark"
                st.session_state["fails"] = 0
                db.log_action(row["username"], "LOGIN", "Signed in")
                st.rerun()
            else:
                st.session_state["fails"] = st.session_state.get("fails", 0) + 1
                db.log_action(username.strip() or "?", "LOGIN_FAILED", "Wrong username or password")
                if st.session_state["fails"] >= 5:
                    st.session_state["locked_until"] = time.time() + 30
                    st.session_state["fails"] = 0
                st.error("Invalid username or password.")
        st.info("Demo accounts - **admin / admin123** (full access) and **hr / hr123456** (HR role). "
                "Change these passwords in Settings → My Account after your first login.")


# --------------------------------------------------------------------------- #
# Dashboard
# --------------------------------------------------------------------------- #
def page_dashboard():
    header("dashboard", f"{t('welcome')}, {me()['full_name'] or me()['username']}! Here is your HR & payroll overview.")
    months = db.q("SELECT DISTINCT month FROM payroll ORDER BY month DESC").month.tolist()
    month_default = months[0] if months else date.today().strftime("%Y-%m")
    c1, c2 = st.columns([3, 1])
    month = c2.selectbox("Month", months or [month_default], format_func=U.month_label)
    emps = employees()
    pay = db.q("SELECT * FROM payroll WHERE month=?", (month,))
    att = db.q("SELECT status FROM attendance WHERE date LIKE ?", (month + "%",))
    present = int(att.status.isin(["Present", "Work From Home"]).sum()) + 0.5 * int((att.status == "Half Day").sum())
    denom = int(att.status.isin(["Present", "Work From Home", "Half Day", "Absent"]).sum())
    att_pct = f"{present / denom * 100:.1f}%" if denom else "N/A"
    pending_leaves = db.scalar("SELECT COUNT(*) FROM leaves WHERE status='Pending'")
    active = int((emps.status == "Active").sum())
    st.markdown(U.kpi_cards([
        ("👥", t("total_employees"), len(emps), f"{active} active"),
        ("💰", t("monthly_payroll"), money(pay.gross.sum()), f"Gross · {U.month_label(month)}"),
        ("🕒", t("attendance_pct"), att_pct, "Present + WFH (half-days = 0.5)"),
        ("🌴", t("pending_leaves"), pending_leaves, "Awaiting approval"),
        ("💵", t("net_salary"), money(pay.net.sum()), f"{len(pay)} payslips"),
    ]), unsafe_allow_html=True)

    a, b = st.columns([3, 2])
    with a:
        trend = db.q("SELECT month, SUM(gross) Gross, SUM(net) Net, SUM(total_ded) Deductions FROM payroll "
                     "GROUP BY month ORDER BY month DESC LIMIT 12").sort_values("month")
        if trend.empty:
            st.info("No payroll processed yet. Use the Payroll page to process your first month.")
        else:
            fig = go.Figure()
            fig.add_bar(x=trend.month, y=trend.Gross, name="Gross", marker_color="#7c3aed")
            fig.add_bar(x=trend.month, y=trend.Net, name="Net", marker_color="#ec4899")
            fig.add_scatter(x=trend.month, y=trend.Deductions, name="Deductions", mode="lines+markers",
                            line=dict(color="#3b82f6", width=3))
            fig.update_layout(title="Monthly payroll", barmode="group")
            plot(fig)
    with b:
        dept = emps[emps.status != "Inactive"].groupby("department").size().reset_index(name="Employees")
        fig = px.pie(dept, names="department", values="Employees", hole=.45, title="Employees by department",
                     color_discrete_sequence=U.PALETTE)
        plot(fig)

    a, b, c = st.columns(3)
    with a:
        st.markdown(f"#### 📌 {t('payroll_status')}")
        if pay.empty:
            st.caption("No payroll for this month.")
        else:
            sc = pay.groupby("status").agg(Employees=("id", "count"), Net=("net", "sum")).reset_index()
            sc.columns = ["Status", "Employees", "Net"]
            table(sc, badge_cols=("Status",), money_cols=("Net",))
    with b:
        st.markdown(f"#### 🎂 {t('upcoming_birthdays')}")
        rows = []
        for r in emps[emps.status != "Inactive"].itertuples():
            nb = U.next_birthday(r.dob)
            if nb and (nb - date.today()).days <= 30:
                rows.append((nb, r.name, r.department))
        if rows:
            for nb, name, dept_ in sorted(rows)[:6]:
                days = (nb - date.today()).days
                when = "Today 🎉" if days == 0 else f"in {days} day{'s' if days > 1 else ''}"
                st.markdown(f'<div class="card" style="padding:8px 14px;margin-bottom:6px"><b>{name}</b> · {dept_}<br>'
                            f'<small>{nb:%d %b} — {when}</small></div>', unsafe_allow_html=True)
        else:
            st.caption("No birthdays in the next 30 days.")
    with c:
        st.markdown(f"#### 🔔 {t('alerts')}")
        alerts = []
        pend_pay = db.scalar("SELECT COUNT(*) FROM payroll WHERE status='Pending Approval'")
        if pend_pay:
            alerts.append(U.alert_box(f"<b>{pend_pay}</b> payroll entries are waiting for approval.", "warn"))
        if pending_leaves:
            alerts.append(U.alert_box(f"<b>{pending_leaves}</b> leave requests need a decision.", "warn"))
        today = date.today().isoformat()
        soon = (date.today() + timedelta(days=30)).isoformat()
        expired = db.scalar("SELECT COUNT(*) FROM documents WHERE expiry_date<?", (today,))
        expiring = db.scalar("SELECT COUNT(*) FROM documents WHERE expiry_date BETWEEN ? AND ?", (today, soon))
        if expired:
            alerts.append(U.alert_box(f"<b>{expired}</b> employee documents have expired.", "bad"))
        if expiring:
            alerts.append(U.alert_box(f"<b>{expiring}</b> documents expire within 30 days.", "warn"))
        pr_reimb = db.scalar("SELECT COUNT(*) FROM reimbursements WHERE status='Pending'")
        if pr_reimb:
            alerts.append(U.alert_box(f"<b>{pr_reimb}</b> reimbursement claims are pending.", ""))
        cur_month = date.today().strftime("%Y-%m")
        if not db.scalar("SELECT COUNT(*) FROM payroll WHERE month=?", (cur_month,)):
            alerts.append(U.alert_box(f"Payroll for <b>{U.month_label(cur_month)}</b> has not been processed yet.", ""))
        st.markdown("".join(alerts) or U.alert_box("Everything looks good ✅", "ok"), unsafe_allow_html=True)

    a, b = st.columns([3, 2])
    with a:
        st.markdown(f"#### 🕑 {t('recent_activity')}")
        logs = db.q("SELECT ts AS Time, username AS User, action AS Action, details AS Details FROM audit_logs "
                    "ORDER BY id DESC LIMIT 8")
        table(logs)
    with b:
        st.markdown(f"#### ⚡ {t('quick_actions')}")
        acts = [("➕ Add employee", "employees"), ("💰 Process payroll", "payroll"), ("🕒 Mark attendance", "attendance"),
                ("🌴 Review leaves", "leaves"), ("🧾 Download payslips", "payslips"), ("📊 Open reports", "reports")]
        cols = st.columns(2)
        for i, (lab, pg) in enumerate(acts):
            cols[i % 2].button(lab, key=f"qa_{pg}", on_click=goto, args=(pg,))
        att_m = db.q("SELECT status, COUNT(*) AS n FROM attendance WHERE date LIKE ? GROUP BY status", (month + "%",))
        if not att_m.empty:
            fig = px.bar(att_m, x="status", y="n", title="Attendance records this month", color="status",
                         color_discrete_sequence=U.PALETTE)
            fig.update_layout(showlegend=False)
            plot(fig, 260)


# --------------------------------------------------------------------------- #
# Employees
# --------------------------------------------------------------------------- #
def emp_form_fields(prefix, e=None):
    """Shared Add/Edit widgets (must be called inside st.form). Returns dict of values."""
    e = e or {}
    c1, c2 = st.columns(2)
    v = {}
    v["name"] = c1.text_input("Full name *", e.get("name", ""), key=f"{prefix}_name")
    v["email"] = c2.text_input("Email", e.get("email", "") or "", key=f"{prefix}_email")
    v["phone"] = c1.text_input("Phone", e.get("phone", "") or "", key=f"{prefix}_phone")
    v["bank_account"] = c2.text_input("Bank account (masked is fine)", e.get("bank_account", "") or "", key=f"{prefix}_bank")
    v["address"] = st.text_area("Address", e.get("address", "") or "", key=f"{prefix}_addr", height=70)
    depts = list(dict.fromkeys(DEPARTMENTS + ([e["department"]] if e.get("department") else [])))
    v["department"] = c1.selectbox("Department", depts, index=depts.index(e["department"]) if e.get("department") else 0,
                                   key=f"{prefix}_dept")
    v["designation"] = c2.text_input("Designation", e.get("designation", "") or "", key=f"{prefix}_desig")
    v["joining_date"] = c1.date_input("Joining date", U.to_date(e.get("joining_date")) or date.today(), key=f"{prefix}_join",
                                      min_value=date(1980, 1, 1), max_value=date(2100, 1, 1))
    v["dob"] = c2.date_input("Date of birth", U.to_date(e.get("dob")) or date(1995, 1, 1), key=f"{prefix}_dob",
                             min_value=date(1950, 1, 1), max_value=date.today())
    v["basic_salary"] = c1.number_input("Basic salary (monthly) *", min_value=0.0, step=500.0,
                                        value=float(e.get("basic_salary", 25000.0)), key=f"{prefix}_basic")
    v["fixed_allowance"] = c2.number_input("Fixed monthly allowance", min_value=0.0, step=100.0,
                                           value=float(e.get("fixed_allowance", pr.fnum(S.get("default_allowance")))),
                                           key=f"{prefix}_allow")
    stt = e.get("status", "Active")
    v["status"] = c1.selectbox("Status", EMP_STATUS, index=EMP_STATUS.index(stt) if stt in EMP_STATUS else 0,
                               key=f"{prefix}_status")
    v["photo"] = c2.file_uploader("Profile photo (PNG/JPG)", type=["png", "jpg", "jpeg"], key=f"{prefix}_photo")
    return v


def validate_emp(v):
    if not v["name"].strip():
        return "Full name is required."
    if v["email"] and ("@" not in v["email"] or "." not in v["email"].split("@")[-1]):
        return "Please enter a valid email address."
    if v["phone"] and not v["phone"].replace("+", "").replace(" ", "").replace("-", "").isdigit():
        return "Phone may contain only digits, spaces, + and -."
    if v["basic_salary"] <= 0:
        return "Basic salary must be greater than zero."
    return None


def page_employees():
    header("employees", "Add, edit, search and manage your people, promotions and salary revisions.")
    tabs = st.tabs(["📋 Directory", "➕ Add Employee", "✏️ Edit / Delete", "📈 Promotions & Salary Revisions"])
    with tabs[0]:
        df = employees()
        c1, c2, c3 = st.columns([2, 1, 1])
        text = c1.text_input("🔍 Search by ID, name, email or phone", key="emp_search")
        dept = c2.selectbox("Department", ["All"] + sorted(df.department.dropna().unique().tolist()), key="emp_dept")
        stat = c3.selectbox("Status", ["All"] + EMP_STATUS, key="emp_stat")
        f = df.copy()
        if text:
            mask = pd.Series(False, index=f.index)
            for col in ["emp_id", "name", "email", "phone"]:
                mask |= f[col].fillna("").str.contains(text, case=False, regex=False)
            f = f[mask]
        if dept != "All":
            f = f[f.department == dept]
        if stat != "All":
            f = f[f.status == stat]
        st.caption(f"{len(f)} of {len(df)} employees")
        show = f[["emp_id", "name", "department", "designation", "email", "phone", "joining_date", "basic_salary", "status"]]
        table(show.rename(columns={"emp_id": "ID", "name": "Name", "department": "Department", "designation": "Designation",
                                   "email": "Email", "phone": "Phone", "joining_date": "Joined", "basic_salary": "Basic Salary",
                                   "status": "Status"}), badge_cols=("Status",), money_cols=("Basic Salary",))
        csv_button(f, "employees.csv", key="emp_csv")
        st.markdown("#### 👤 Employee profile")
        pick = emp_select("Select employee", "prof_emp")
        if pick:
            e = db.one("SELECT * FROM employees WHERE emp_id=?", (pick,))
            c1, c2 = st.columns([1, 3])
            with c1:
                if e["photo"]:
                    st.image(e["photo"], width=150)
                else:
                    st.markdown(U.avatar_html(e["name"], 110), unsafe_allow_html=True)
            with c2:
                st.markdown(f'<div class="card"><h4>{e["name"]} {U.badge(e["status"])}</h4>'
                            f'<b>{e["designation"] or "-"}</b> · {e["department"] or "-"}<br>'
                            f'📧 {e["email"] or "-"} &nbsp; 📞 {e["phone"] or "-"}<br>📍 {e["address"] or "-"}<br>'
                            f'🗓️ Joined {e["joining_date"] or "-"} &nbsp; 🎂 {e["dob"] or "-"}<br>'
                            f'💰 Basic {money(e["basic_salary"])} + allowance {money(e["fixed_allowance"])}</div>',
                            unsafe_allow_html=True)
            h1, h2 = st.columns(2)
            with h1:
                st.markdown("**Salary revisions**")
                table(db.q("SELECT effective_date AS Date, old_salary AS Old, new_salary AS New, reason AS Reason "
                           "FROM salary_revisions WHERE emp_id=? ORDER BY effective_date DESC", (pick,)),
                      money_cols=("Old", "New"))
            with h2:
                st.markdown("**Promotion history**")
                table(db.q("SELECT effective_date AS Date, old_designation AS 'From', new_designation AS 'To', remarks AS Remarks "
                           "FROM promotions WHERE emp_id=? ORDER BY effective_date DESC", (pick,)))
    with tabs[1]:
        with st.form("add_emp", clear_on_submit=False):
            new_id = st.text_input("Employee ID *", db.next_emp_id(), key="add_id")
            v = emp_form_fields("add")
            go_ = st.form_submit_button("➕ Add employee")
        if go_:
            eid = new_id.strip().upper()
            err = validate_emp(v) or ("Employee ID is required." if not eid else None) or \
                ("That Employee ID already exists." if db.one("SELECT 1 FROM employees WHERE emp_id=?", (eid,)) else None)
            if err:
                st.error(err)
            else:
                photo = U.img_to_bytes(v["photo"]) if v["photo"] else None
                db.run("INSERT INTO employees(emp_id,name,email,phone,address,department,designation,joining_date,dob,"
                       "basic_salary,fixed_allowance,status,bank_account,photo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (eid, v["name"].strip(), v["email"], v["phone"], v["address"], v["department"], v["designation"],
                        v["joining_date"].isoformat(), v["dob"].isoformat(), v["basic_salary"], v["fixed_allowance"],
                        v["status"], v["bank_account"], photo))
                audit("ADD_EMPLOYEE", f"Added {eid} - {v['name']}")
                flash(f"Employee {eid} added.")
                st.rerun()
    with tabs[2]:
        pick = emp_select("Select employee to edit", "edit_emp")
        if pick and can("edit_employee"):
            e = db.one("SELECT * FROM employees WHERE emp_id=?", (pick,))
            with st.form(f"edit_{pick}"):
                st.text_input("Employee ID (cannot be changed)", pick, disabled=True, key=f"ed_id_{pick}")
                v = emp_form_fields(f"ed_{pick}", e)
                remove = st.checkbox("Remove current photo", key=f"ed_rm_{pick}")
                go_ = st.form_submit_button("💾 Save changes")
            if go_:
                err = validate_emp(v)
                if err:
                    st.error(err)
                else:
                    photo = U.img_to_bytes(v["photo"]) if v["photo"] else (None if remove else e["photo"])
                    db.run("UPDATE employees SET name=?,email=?,phone=?,address=?,department=?,designation=?,joining_date=?,"
                           "dob=?,basic_salary=?,fixed_allowance=?,status=?,bank_account=?,photo=? WHERE emp_id=?",
                           (v["name"].strip(), v["email"], v["phone"], v["address"], v["department"], v["designation"],
                            v["joining_date"].isoformat(), v["dob"].isoformat(), v["basic_salary"], v["fixed_allowance"],
                            v["status"], v["bank_account"], photo, pick))
                    if abs(v["basic_salary"] - float(e["basic_salary"])) > 0.001:
                        db.run("INSERT INTO salary_revisions(emp_id,old_salary,new_salary,effective_date,reason,created_by) "
                               "VALUES(?,?,?,?,?,?)", (pick, e["basic_salary"], v["basic_salary"], date.today().isoformat(),
                                                       "Edited in employee record", me()["username"]))
                    audit("EDIT_EMPLOYEE", f"Edited {pick}")
                    flash(f"Employee {pick} updated.")
                    st.rerun()
            st.markdown("---")
            st.markdown("##### 🗑️ Delete employee")
            if can("delete_employee"):
                st.warning("Deleting removes the employee **and** their payroll, attendance, leave and other records. "
                           "Consider setting the status to *Inactive* instead.")
                ok = st.checkbox(f"Yes, permanently delete {pick}", key=f"del_ok_{pick}")
                if st.button("Delete employee", disabled=not ok, key=f"del_btn_{pick}"):
                    db.run("DELETE FROM employees WHERE emp_id=?", (pick,))
                    audit("DELETE_EMPLOYEE", f"Deleted {pick} - {e['name']}")
                    flash(f"Employee {pick} deleted.")
                    st.rerun()
            else:
                st.info("Only an Admin can delete employees. You can mark the employee Inactive above.")
    with tabs[3]:
        st.markdown("##### Record a promotion / salary revision")
        pick = emp_select("Employee", "promo_emp", statuses=["Active", "On Leave"])
        if pick:
            e = db.one("SELECT designation, department, basic_salary FROM employees WHERE emp_id=?", (pick,))
            with st.form(f"promo_{pick}"):
                c1, c2 = st.columns(2)
                nd = c1.text_input("New designation", e["designation"] or "", key=f"pr_d_{pick}")
                depts = list(dict.fromkeys(DEPARTMENTS + ([e["department"]] if e["department"] else [])))
                ndept = c2.selectbox("New department", depts, index=depts.index(e["department"]) if e["department"] else 0,
                                     key=f"pr_dep_{pick}")
                ns = c1.number_input("New basic salary", min_value=0.0, step=500.0, value=float(e["basic_salary"]), key=f"pr_s_{pick}")
                eff = c2.date_input("Effective date", date.today(), key=f"pr_e_{pick}")
                rem = st.text_input("Remarks / reason", key=f"pr_r_{pick}")
                go_ = st.form_submit_button("📈 Save promotion / revision")
            if go_:
                changed = False
                if nd != (e["designation"] or "") or ndept != e["department"]:
                    db.run("INSERT INTO promotions(emp_id,old_designation,new_designation,old_department,new_department,"
                           "effective_date,remarks) VALUES(?,?,?,?,?,?,?)",
                           (pick, e["designation"], nd, e["department"], ndept, eff.isoformat(), rem))
                    db.run("UPDATE employees SET designation=?, department=? WHERE emp_id=?", (nd, ndept, pick))
                    changed = True
                if abs(ns - float(e["basic_salary"])) > 0.001 and ns > 0:
                    db.run("INSERT INTO salary_revisions(emp_id,old_salary,new_salary,effective_date,reason,created_by) "
                           "VALUES(?,?,?,?,?,?)", (pick, e["basic_salary"], ns, eff.isoformat(), rem or "Revision", me()["username"]))
                    db.run("UPDATE employees SET basic_salary=? WHERE emp_id=?", (ns, pick))
                    changed = True
                if changed:
                    audit("PROMOTION_REVISION", f"{pick}: {nd} / {ns}")
                    flash("Saved successfully.")
                    st.rerun()
                else:
                    st.warning("Nothing changed - modify the designation, department or salary first.")
        a, b = st.columns(2)
        with a:
            st.markdown("**All promotions**")
            table(db.q("SELECT p.effective_date AS Date, p.emp_id AS ID, e.name AS Name, p.old_designation AS 'From', "
                       "p.new_designation AS 'To', p.remarks AS Remarks FROM promotions p JOIN employees e ON e.emp_id=p.emp_id "
                       "ORDER BY p.effective_date DESC"))
        with b:
            st.markdown("**All salary revisions**")
            table(db.q("SELECT r.effective_date AS Date, r.emp_id AS ID, e.name AS Name, r.old_salary AS Old, r.new_salary AS New, "
                       "r.reason AS Reason FROM salary_revisions r JOIN employees e ON e.emp_id=r.emp_id "
                       "ORDER BY r.effective_date DESC"), money_cols=("Old", "New"))


# --------------------------------------------------------------------------- #
# Payroll
# --------------------------------------------------------------------------- #
def page_payroll():
    header("payroll", "Calculate salaries, process a month, approve and track payroll history.")
    tabs = st.tabs(["⚙️ Process Payroll", "✅ Approval & Status", "🗂️ Payroll History", "🧮 How salary is calculated"])
    with tabs[0]:
        months = U.month_options(12)
        month = st.selectbox("Payroll month", months, format_func=U.month_label, key="pay_month")
        emps = employees(["Active", "On Leave"])
        done = set(db.q("SELECT emp_id FROM payroll WHERE month=?", (month,)).emp_id)
        todo = emps[~emps.emp_id.isin(done)].copy()
        if done:
            st.info(f"{len(done)} employee(s) already have payroll for {U.month_label(month)}. "
                    "Duplicate entries are blocked automatically.")
        if todo.empty:
            st.success(f"Payroll for {U.month_label(month)} is fully processed for all active employees. ✅")
        else:
            auto_ot = S.get("ot_from_attendance") == "1"
            todo["Select"] = True
            todo["Bonus"] = 0.0
            todo["Overtime Hrs"] = [round(pr.attendance_summary(e, month, S)["ot_hours"], 1) if auto_ot else 0.0
                                    for e in todo.emp_id]
            todo["Other Deductions"] = 0.0
            st.caption("Tick the employees to include. You can edit Bonus, Overtime hours and Other deductions. "
                       "LOP (absent days), PF, tax, loans/advances and approved reimbursements are added automatically.")
            ed = st.data_editor(
                todo[["Select", "emp_id", "name", "department", "basic_salary", "Bonus", "Overtime Hrs", "Other Deductions"]],
                key=f"pay_ed_{month}", hide_index=True, use_container_width=True,
                disabled=["emp_id", "name", "department", "basic_salary"],
                column_config={"Select": st.column_config.CheckboxColumn("Include"),
                               "emp_id": "ID", "name": "Name", "department": "Department",
                               "basic_salary": st.column_config.NumberColumn("Basic", format="%.2f"),
                               "Bonus": st.column_config.NumberColumn(min_value=0.0, step=500.0, format="%.2f"),
                               "Overtime Hrs": st.column_config.NumberColumn(min_value=0.0, step=0.5, format="%.1f"),
                               "Other Deductions": st.column_config.NumberColumn(min_value=0.0, step=100.0, format="%.2f")})
            sel = ed[ed.Select]
            inputs, prev = {}, []
            for _, r in sel.iterrows():
                inp = {"bonus": float(r["Bonus"]), "overtime_hours": float(r["Overtime Hrs"]),
                       "other_ded": float(r["Other Deductions"])}
                inputs[r["emp_id"]] = inp
                c = pr.compute_for_employee(r["emp_id"], month, S, **inp)
                prev.append({"ID": r["emp_id"], "Name": r["name"], "Gross": c["gross"], "LOP days": c["lop_days"],
                             "Deductions": c["total_ded"], "Net": c["net"]})
            if prev:
                pv = pd.DataFrame(prev)
                st.markdown("**Preview**")
                table(pv, money_cols=("Gross", "Deductions", "Net"))
                k1, k2, k3 = st.columns(3)
                k1.metric("Employees", len(pv))
                k2.metric("Total gross", money(pv.Gross.sum()))
                k3.metric("Total net", money(pv.Net.sum()))
            if can("process_payroll") and st.button("🚀 Process payroll for selected employees", disabled=not prev):
                created, skipped = pr.process_payroll(list(inputs), month, inputs, me()["username"], S)
                audit("PROCESS_PAYROLL", f"{U.month_label(month)}: {len(created)} processed, {len(skipped)} skipped")
                flash(f"Processed {len(created)} payroll entries for {U.month_label(month)}"
                      + (f" ({len(skipped)} skipped as duplicates)." if skipped else ".") + " They now await admin approval.")
                st.rerun()
    with tabs[1]:
        c1, c2 = st.columns(2)
        months_db = db.q("SELECT DISTINCT month FROM payroll ORDER BY month DESC").month.tolist()
        m = c1.selectbox("Month", months_db or [date.today().strftime("%Y-%m")], format_func=U.month_label, key="appr_month")
        stat = c2.selectbox("Status", ["All", "Pending Approval", "Approved", "Paid", "Rejected"], key="appr_stat")
        sql = ("SELECT p.id, p.emp_id, e.name, e.department, p.gross, p.total_ded, p.net, p.status FROM payroll p "
               "JOIN employees e ON e.emp_id=p.emp_id WHERE p.month=?")
        params = [m]
        if stat != "All":
            sql += " AND p.status=?"
            params.append(stat)
        df = db.q(sql + " ORDER BY p.emp_id", tuple(params))
        if df.empty:
            st.info("No payroll entries for this selection.")
        else:
            counts = df.status.value_counts()
            st.markdown(" ".join(f"{U.badge(k)} **{v}**" for k, v in counts.items()), unsafe_allow_html=True)
            df.insert(0, "Select", False)
            ed = st.data_editor(df, key=f"appr_ed_{m}_{stat}", hide_index=True, use_container_width=True,
                                disabled=[c for c in df.columns if c != "Select"],
                                column_config={"gross": st.column_config.NumberColumn("Gross", format="%.2f"),
                                               "total_ded": st.column_config.NumberColumn("Deductions", format="%.2f"),
                                               "net": st.column_config.NumberColumn("Net", format="%.2f"),
                                               "emp_id": "Emp ID", "name": "Name", "department": "Department",
                                               "status": "Status"})
            ids = ed[ed.Select].id.tolist()
            st.caption(f"{len(ids)} selected")
            b1, b2, b3, b4 = st.columns(4)
            if can("approve_payroll"):
                if b1.button("✅ Approve", disabled=not ids):
                    n = pr.approve_payroll(ids, me()["username"])
                    audit("APPROVE_PAYROLL", f"Approved {n} entries for {m}")
                    flash(f"Approved {n} entries (loan/advance balances updated).")
                    st.rerun()
                if b2.button("❌ Reject", disabled=not ids):
                    n = pr.reject_payroll(ids, me()["username"])
                    audit("REJECT_PAYROLL", f"Rejected {n} entries for {m}")
                    flash(f"Rejected {n} entries. Delete them to re-process.", "warning")
                    st.rerun()
                if b3.button("💸 Mark as paid", disabled=not ids):
                    mark = pr.mark_paid(ids)
                    audit("MARK_PAID", f"Marked paid: {mark} selected for {m}")
                    flash("Approved entries marked as paid.")
                    st.rerun()
            else:
                st.info("🔒 Only an Admin can approve, reject or mark payroll as paid (approval workflow).")
            if b4.button("🗑️ Delete (pending/rejected)", disabled=not ids):
                n = pr.delete_payroll(ids)
                audit("DELETE_PAYROLL", f"Deleted {n} pending/rejected entries for {m}")
                flash(f"Deleted {n} entries - you can process them again.")
                st.rerun()
            st.caption("Approved and paid entries are locked and cannot be deleted.")
    with tabs[2]:
        c1, c2 = st.columns(2)
        pick = emp_select("Employee", "hist_emp", allow_all=True)
        year = c2.selectbox("Year", ["All"] + [str(y) for y in range(date.today().year, date.today().year - 5, -1)], key="hist_year")
        sql = ("SELECT p.month, p.emp_id, e.name, p.basic, p.hra, p.da, p.allowances, p.bonus, p.overtime, p.reimbursements, "
               "p.gross, p.pf, p.tax, p.prof_tax, p.loan_ded, p.advance_ded, p.lop_amount, p.other_ded, p.total_ded, p.net, "
               "p.status FROM payroll p JOIN employees e ON e.emp_id=p.emp_id WHERE 1=1")
        params = []
        if pick and pick != "__all__":
            sql += " AND p.emp_id=?"
            params.append(pick)
        if year != "All":
            sql += " AND substr(p.month,1,4)=?"
            params.append(year)
        hist = db.q(sql + " ORDER BY p.month DESC, p.emp_id", tuple(params))
        st.caption(f"{len(hist)} records")
        table(hist, badge_cols=("status",), money_cols=("basic", "hra", "da", "allowances", "bonus", "overtime", "reimbursements",
                                                        "gross", "pf", "tax", "prof_tax", "loan_ded", "advance_ded", "lop_amount",
                                                        "other_ded", "total_ded", "net"), max_rows=100)
        csv_button(hist, "payroll_history.csv", key="hist_csv")
    with tabs[3]:
        st.markdown(f"""
**Earnings** — Basic + HRA ({S.get('hra_pct')}% of basic) + DA ({S.get('da_pct')}% of basic) + fixed allowance + bonus
+ overtime + approved reimbursements = **Gross**.

**Overtime** = overtime hours × (basic ÷ {S.get('working_days')} days ÷ {S.get('hours_per_day')} hrs) × {S.get('overtime_multiplier')}.

**Deductions** — PF ({S.get('pf_rate')}% of basic + DA, cap {S.get('pf_wage_cap')} where 0 = no cap) · income tax
(monthly slabs: 0% up to {money(S.get('tax_slab1_limit'))}, {S.get('tax_slab2_pct')}% up to {money(S.get('tax_slab2_limit'))},
{S.get('tax_slab3_pct')}% above) · professional tax ({money(S.get('prof_tax'))} when pay ≥ {money(S.get('prof_tax_threshold'))}) ·
loan EMI · salary-advance recovery · loss-of-pay · other deductions.

**Loss of pay (LOP)** = (absent days not covered by approved paid leave + unpaid leave days + ½ × half-days) × (basic ÷ {S.get('working_days')}).
LOP is {'**ON**' if S.get('apply_lop') == '1' else '**OFF**'} and overtime from attendance is
{'**ON**' if S.get('ot_from_attendance') == '1' else '**OFF**'} (change in Settings → Payroll Settings).

**Net take-home** = Gross − Total deductions. Tax is calculated on gross minus reimbursements and LOP.

**Workflow** — HR/Admin processes → *Pending Approval* → Admin approves → *Approved* → Admin marks *Paid*.
Loan balances reduce when payroll is approved.
""")


# --------------------------------------------------------------------------- #
# Payslips
# --------------------------------------------------------------------------- #
def page_payslips():
    header("payslips", "Download professional PDF payslips and monthly payroll summary reports.")
    months = db.q("SELECT DISTINCT month FROM payroll ORDER BY month DESC").month.tolist()
    if not months:
        st.info("No payroll has been processed yet. Process payroll first, then come back for payslips.")
        return
    month = st.selectbox("Payroll month", months, format_func=U.month_label, key="ps_month")
    df = db.q("SELECT p.*, e.name FROM payroll p JOIN employees e ON e.emp_id=p.emp_id WHERE p.month=? AND p.status<>'Rejected' "
              "ORDER BY p.emp_id", (month,))
    tabs = st.tabs(["🧾 Individual payslip", "📦 All payslips (ZIP)", "📑 Monthly summary report"])
    with tabs[0]:
        if df.empty:
            st.info("No payslips available for this month.")
        else:
            labels = {r.emp_id: f"{r.emp_id} · {r.name}" for r in df.itertuples()}
            eid = st.selectbox("Employee", list(labels), format_func=labels.get, key="ps_emp")
            pay = df[df.emp_id == eid].iloc[0].to_dict()
            emp = db.one(f"SELECT {EMP_COLS} FROM employees WHERE emp_id=?", (eid,))
            st.markdown(f'<div class="card"><h4>{emp["name"]} · {U.month_label(month)} {U.badge(pay["status"])}</h4>'
                        f'{emp["designation"] or ""} · {emp["department"] or ""}</div>', unsafe_allow_html=True)
            a, b = st.columns(2)
            earn = pd.DataFrame([("Basic salary", pay["basic"]), ("HRA", pay["hra"]), ("DA", pay["da"]),
                                 ("Allowances", pay["allowances"]), ("Bonus", pay["bonus"]), ("Overtime", pay["overtime"]),
                                 ("Reimbursements", pay["reimbursements"]), ("Gross", pay["gross"])], columns=["Earnings", "Amount"])
            ded = pd.DataFrame([("Provident fund", pay["pf"]), ("Income tax", pay["tax"]), ("Professional tax", pay["prof_tax"]),
                                ("Loan EMI", pay["loan_ded"]), ("Salary advance", pay["advance_ded"]),
                                (f"Loss of pay ({pay['lop_days']:g} d)", pay["lop_amount"]), ("Other", pay["other_ded"]),
                                ("Total deductions", pay["total_ded"])], columns=["Deductions", "Amount"])
            with a:
                table(earn, money_cols=("Amount",))
            with b:
                table(ded, money_cols=("Amount",))
            st.markdown(U.kpi_cards([("💵", "Net take-home", money(pay["net"]), U.month_label(month))]), unsafe_allow_html=True)
            pdf = U.payslip_pdf(S, emp, pay, month)
            st.download_button("⬇️ Download payslip (PDF)", pdf, file_name=f"payslip_{eid}_{month}.pdf",
                               mime="application/pdf", key=f"dl_ps_{eid}_{month}")
    with tabs[1]:
        st.write(f"Create a ZIP with one PDF payslip per employee for **{U.month_label(month)}** ({len(df)} payslips).")
        if st.button("📦 Prepare ZIP", disabled=df.empty, key=f"zipbtn_{month}"):
            items = []
            for r in df.itertuples():
                emp = db.one(f"SELECT {EMP_COLS} FROM employees WHERE emp_id=?", (r.emp_id,))
                items.append((emp, df[df.emp_id == r.emp_id].iloc[0].to_dict()))
            st.session_state[f"zip_{month}"] = U.payslips_zip(S, items, month)
        if st.session_state.get(f"zip_{month}"):
            st.download_button("⬇️ Download ZIP", st.session_state[f"zip_{month}"], file_name=f"payslips_{month}.zip",
                               mime="application/zip", key=f"zipdl_{month}")
    with tabs[2]:
        if df.empty:
            st.info("Nothing to summarise.")
        else:
            summ = db.q("SELECT p.emp_id AS ID, e.name AS Name, e.department AS Department, p.gross AS Gross, "
                        "p.total_ded AS Deductions, p.net AS Net, p.status AS Status FROM payroll p JOIN employees e "
                        "ON e.emp_id=p.emp_id WHERE p.month=? AND p.status<>'Rejected' ORDER BY p.emp_id", (month,))
            st.markdown(U.kpi_cards([("👥", "Employees", len(summ), U.month_label(month)),
                                     ("💰", "Total gross", money(summ.Gross.sum()), ""),
                                     ("➖", "Total deductions", money(summ.Deductions.sum()), ""),
                                     ("💵", "Total net", money(summ.Net.sum()), "")]), unsafe_allow_html=True)
            table(summ, badge_cols=("Status",), money_cols=("Gross", "Deductions", "Net"))
            ds = summ.groupby("Department")[["Gross", "Net"]].sum().reset_index()
            plot(px.bar(ds, x="Department", y=["Gross", "Net"], barmode="group", title="Payroll by department",
                        color_discrete_sequence=U.PALETTE), 320)
            c1, c2 = st.columns(2)
            with c1:
                csv_button(summ, f"payroll_summary_{month}.csv", key="ps_sum_csv")
            with c2:
                pdf = U.report_pdf("Monthly Payroll Summary", summ, S, U.month_label(month),
                                   [("Employees", len(summ)), ("Gross", money(summ.Gross.sum())),
                                    ("Deductions", money(summ.Deductions.sum())), ("Net", money(summ.Net.sum()))],
                                   money_cols=("Gross", "Deductions", "Net"))
                st.download_button("⬇️ Download summary (PDF)", pdf, file_name=f"payroll_summary_{month}.pdf",
                                   mime="application/pdf", key="ps_sum_pdf")


# --------------------------------------------------------------------------- #
# Attendance
# --------------------------------------------------------------------------- #
def page_attendance():
    header("attendance", "Record daily attendance, search history and view monthly summaries.")
    tabs = st.tabs(["✍️ Mark Attendance", "🔎 Search & History", "📊 Monthly Summary"])
    with tabs[0]:
        day = st.date_input("Date", date.today(), key="att_date")
        hol = db.one("SELECT name FROM holidays WHERE date=?", (day.isoformat(),))
        if hol:
            st.info(f"🎉 {day:%d %b %Y} is a company holiday: **{hol['name']}**. Default status set to Holiday.")
        emps = employees(["Active", "On Leave"])
        existing = db.q("SELECT emp_id, status, check_in, check_out FROM attendance WHERE date=?", (day.isoformat(),)).set_index("emp_id")
        rows = []
        for r in emps.itertuples():
            if r.emp_id in existing.index:
                ex = existing.loc[r.emp_id]
                rows.append((r.emp_id, r.name, ex["status"], ex["check_in"] or "", ex["check_out"] or ""))
            elif hol:
                rows.append((r.emp_id, r.name, "Holiday", "", ""))
            else:
                rows.append((r.emp_id, r.name, "Present", "09:30", "18:00"))
        base = pd.DataFrame(rows, columns=["emp_id", "name", "status", "check_in", "check_out"])
        st.caption("Set the status and enter times as HH:MM (24-hour). Existing records for the date are loaded for editing.")
        ed = st.data_editor(base, key=f"att_ed_{day}", hide_index=True, use_container_width=True,
                            disabled=["emp_id", "name"],
                            column_config={"emp_id": "ID", "name": "Name",
                                           "status": st.column_config.SelectboxColumn("Status", options=ATT_STATUS, required=True),
                                           "check_in": st.column_config.TextColumn("Check-in (HH:MM)", max_chars=5),
                                           "check_out": st.column_config.TextColumn("Check-out (HH:MM)", max_chars=5)})
        if st.button("💾 Save attendance", key=f"att_save_{day}"):
            bad = [r.emp_id for r in ed.itertuples() if not (valid_hhmm(r.check_in) and valid_hhmm(r.check_out))]
            if bad:
                st.error("Invalid time format for: " + ", ".join(bad) + ". Use HH:MM, e.g. 09:30.")
            else:
                for r in ed.itertuples():
                    ci = r.check_in if r.check_in not in (None, "", "None") else None
                    co = r.check_out if r.check_out not in (None, "", "None") else None
                    db.run("INSERT INTO attendance(emp_id,date,status,check_in,check_out) VALUES(?,?,?,?,?) "
                           "ON CONFLICT(emp_id,date) DO UPDATE SET status=excluded.status, check_in=excluded.check_in, "
                           "check_out=excluded.check_out", (r.emp_id, day.isoformat(), r.status, ci, co))
                audit("MARK_ATTENDANCE", f"Attendance saved for {day.isoformat()} ({len(ed)} employees)")
                flash(f"Attendance saved for {day:%d %b %Y}.")
                st.rerun()
    with tabs[1]:
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            pick = emp_select("Employee", "att_search_emp", allow_all=True)
        d1 = c2.date_input("From", date.today().replace(day=1), key="att_from")
        d2 = c3.date_input("To", date.today(), key="att_to")
        stt = c4.selectbox("Status", ["All"] + ATT_STATUS, key="att_stat")
        sql = ("SELECT a.date AS Date, a.emp_id AS ID, e.name AS Name, a.status AS Status, a.check_in AS 'Check-in', "
               "a.check_out AS 'Check-out' FROM attendance a JOIN employees e ON e.emp_id=a.emp_id WHERE a.date BETWEEN ? AND ?")
        params = [d1.isoformat(), d2.isoformat()]
        if pick and pick != "__all__":
            sql += " AND a.emp_id=?"
            params.append(pick)
        if stt != "All":
            sql += " AND a.status=?"
            params.append(stt)
        res = db.q(sql + " ORDER BY a.date DESC, a.emp_id", tuple(params))
        if not res.empty:
            res["Hours"] = [round(pr.worked_hours(a, b), 2) for a, b in zip(res["Check-in"], res["Check-out"])]
        st.caption(f"{len(res)} records")
        table(res, badge_cols=("Status",), max_rows=150)
        csv_button(res, "attendance_search.csv", key="att_csv")
    with tabs[2]:
        month = st.selectbox("Month", U.month_options(12), format_func=U.month_label, key="att_sum_month")
        rows = []
        for r in employees(["Active", "On Leave"]).itertuples():
            sm = pr.attendance_summary(r.emp_id, month, S)
            rows.append({"ID": r.emp_id, "Name": r.name, "Present": sm["present"], "WFH": sm["wfh"], "Half-day": sm["half_day"],
                         "Absent": sm["absent"], "Leave": sm["leave"], "Holiday": sm["holiday"], "LOP days": sm["lop_days"],
                         "Hours": sm["worked_hours"], "Overtime hrs": sm["ot_hours"], "Attendance %": sm["attendance_pct"]})
        sdf = pd.DataFrame(rows)
        if sdf.empty or sdf[["Present", "WFH", "Half-day", "Absent"]].sum().sum() == 0:
            st.info("No attendance recorded for this month yet.")
        else:
            table(sdf)
            plot(px.bar(sdf.sort_values("Attendance %"), x="Name", y="Attendance %", title="Attendance % by employee",
                        color="Attendance %", color_continuous_scale=["#ec4899", "#a78bfa", "#7c3aed"]), 340)
            csv_button(sdf, f"attendance_summary_{month}.csv", key="att_sum_csv")


# --------------------------------------------------------------------------- #
# Leave management
# --------------------------------------------------------------------------- #
def page_leaves():
    header("leaves", "Apply for leave, approve or reject requests and track balances.")
    tabs = st.tabs(["📝 Apply for Leave", "✅ Approvals", "⚖️ Leave Balances", "📜 Leave History"])
    with tabs[0]:
        pick = emp_select("Employee", "lv_emp", statuses=["Active", "On Leave"])
        if pick:
            with st.form("leave_form"):
                c1, c2 = st.columns(2)
                ltype = c1.selectbox("Leave type", pr.LEAVE_TYPES)
                reason = c2.text_input("Reason")
                d1 = c1.date_input("From", date.today())
                d2 = c2.date_input("To", date.today())
                go_ = st.form_submit_button("📨 Submit leave request")
            if go_:
                if d2 < d1:
                    st.error("The end date cannot be before the start date.")
                else:
                    days = pr.leave_days(d1, d2)
                    bal = next(r for r in pr.leave_balance(pick, d1.year, S) if r["leave_type"] == ltype)
                    overlap = db.scalar("SELECT COUNT(*) FROM leaves WHERE emp_id=? AND status IN ('Pending','Approved') "
                                        "AND start_date<=? AND end_date>=?", (pick, d2.isoformat(), d1.isoformat()))
                    if days == 0:
                        st.error("The selected dates only contain Sundays - no leave needed.")
                    elif overlap:
                        st.error("This employee already has a pending/approved leave overlapping those dates.")
                    elif bal["balance"] is not None and days > bal["balance"] - bal["pending"]:
                        st.error(f"Insufficient {ltype} balance: {bal['balance'] - bal['pending']:g} day(s) available "
                                 f"(after pending requests), {days:g} requested.")
                    else:
                        db.run("INSERT INTO leaves(emp_id,leave_type,start_date,end_date,days,reason,status,applied_on) "
                               "VALUES(?,?,?,?,?,?,'Pending',?)", (pick, ltype, d1.isoformat(), d2.isoformat(), days, reason,
                                                                  date.today().isoformat()))
                        audit("APPLY_LEAVE", f"{pick} {ltype} {d1}→{d2} ({days:g} days)")
                        flash(f"Leave request submitted ({days:g} working day(s)).")
                        st.rerun()
    with tabs[1]:
        pend = db.q("SELECT l.id, l.emp_id, e.name, l.leave_type, l.start_date, l.end_date, l.days, l.reason FROM leaves l "
                    "JOIN employees e ON e.emp_id=l.emp_id WHERE l.status='Pending' ORDER BY l.start_date")
        if pend.empty:
            st.success("No pending leave requests. 🎉")
        elif not can("approve_leave"):
            st.info("You do not have permission to approve leave.")
        else:
            for r in pend.itertuples():
                c = st.columns([3, 2, 1.2, 1.2])
                c[0].markdown(f"**{r.name}** ({r.emp_id})<br><small>{r.leave_type} · {r.reason or 'No reason given'}</small>",
                              unsafe_allow_html=True)
                c[1].markdown(f"{r.start_date} → {r.end_date}<br><small>{r.days:g} day(s)</small>", unsafe_allow_html=True)
                if c[2].button("✅ Approve", key=f"lv_ok_{r.id}"):
                    db.run("UPDATE leaves SET status='Approved', decided_by=?, decided_on=? WHERE id=?",
                           (me()["username"], date.today().isoformat(), r.id))
                    audit("APPROVE_LEAVE", f"Approved leave #{r.id} for {r.emp_id}")
                    flash(f"Leave for {r.name} approved.")
                    st.rerun()
                if c[3].button("❌ Reject", key=f"lv_no_{r.id}"):
                    db.run("UPDATE leaves SET status='Rejected', decided_by=?, decided_on=? WHERE id=?",
                           (me()["username"], date.today().isoformat(), r.id))
                    audit("REJECT_LEAVE", f"Rejected leave #{r.id} for {r.emp_id}")
                    flash(f"Leave for {r.name} rejected.", "warning")
                    st.rerun()
    with tabs[2]:
        year = st.selectbox("Year", [date.today().year, date.today().year - 1], key="lv_year")
        pick = emp_select("Employee", "lv_bal_emp", allow_all=True)
        ids = employees(["Active", "On Leave"]).emp_id.tolist() if pick == "__all__" else [pick]
        names = dict(zip(employees().emp_id, employees().name))
        rows = []
        for eid in ids:
            for r in pr.leave_balance(eid, year, S):
                rows.append({"ID": eid, "Name": names.get(eid, ""), "Leave type": r["leave_type"],
                             "Annual quota": "Unlimited" if r["quota"] is None else r["quota"], "Used": r["used"],
                             "Pending": r["pending"], "Balance": "-" if r["balance"] is None else r["balance"]})
        table(pd.DataFrame(rows))
    with tabs[3]:
        c1, c2, c3 = st.columns(3)
        with c1:
            pick = emp_select("Employee", "lv_hist_emp", allow_all=True)
        stt = c2.selectbox("Status", ["All", "Pending", "Approved", "Rejected"], key="lv_hist_stat")
        lt = c3.selectbox("Type", ["All"] + pr.LEAVE_TYPES, key="lv_hist_type")
        sql = ("SELECT l.id AS ID, l.emp_id AS Emp, e.name AS Name, l.leave_type AS Type, l.start_date AS 'From', l.end_date AS 'To', "
               "l.days AS Days, l.reason AS Reason, l.status AS Status, l.decided_by AS 'Decided by' FROM leaves l "
               "JOIN employees e ON e.emp_id=l.emp_id WHERE 1=1")
        params = []
        if pick and pick != "__all__":
            sql += " AND l.emp_id=?"
            params.append(pick)
        if stt != "All":
            sql += " AND l.status=?"
            params.append(stt)
        if lt != "All":
            sql += " AND l.leave_type=?"
            params.append(lt)
        hist = db.q(sql + " ORDER BY l.start_date DESC", tuple(params))
        table(hist, badge_cols=("Status",))
        csv_button(hist, "leave_history.csv", key="lv_csv")


# --------------------------------------------------------------------------- #
# Performance reviews
# --------------------------------------------------------------------------- #
def page_performance():
    header("performance", "Record employee performance reviews and ratings.")
    with st.expander("➕ Add a performance review", expanded=False):
        pick = emp_select("Employee", "pf_emp", statuses=["Active", "On Leave"])
        if pick:
            with st.form("review_form"):
                c1, c2, c3 = st.columns(3)
                period = c1.text_input("Review period", f"{date.today().year} H1")
                rating = c2.slider("Rating (1-5)", 1.0, 5.0, 3.5, 0.5)
                reviewer = c3.text_input("Reviewer", me()["full_name"] or me()["username"])
                strengths = st.text_input("Strengths")
                improve = st.text_input("Areas to improve")
                comments = st.text_area("Comments", height=70)
                go_ = st.form_submit_button("💾 Save review")
            if go_:
                if not period.strip():
                    st.error("Review period is required.")
                else:
                    db.run("INSERT INTO reviews(emp_id,period,rating,reviewer,strengths,improvements,comments,review_date) "
                           "VALUES(?,?,?,?,?,?,?,?)", (pick, period, rating, reviewer, strengths, improve, comments,
                                                      date.today().isoformat()))
                    audit("ADD_REVIEW", f"{pick}: {rating} for {period}")
                    flash("Review saved.")
                    st.rerun()
    df = db.q("SELECT r.id, r.review_date AS date, r.emp_id, e.name, e.department, r.period, r.rating, r.reviewer, r.strengths, "
              "r.improvements, r.comments FROM reviews r JOIN employees e ON e.emp_id=r.emp_id ORDER BY r.review_date DESC")
    if df.empty:
        st.info("No reviews yet.")
        return
    st.markdown(U.kpi_cards([("⭐", "Average rating", f"{df.rating.mean():.2f} / 5", f"{len(df)} reviews"),
                             ("🏆", "Top performers (≥4.5)", int((df.rating >= 4.5).sum()), "Reviews"),
                             ("📉", "Needs attention (<3)", int((df.rating < 3).sum()), "Reviews")]), unsafe_allow_html=True)
    a, b = st.columns(2)
    with a:
        d = df.groupby("department").rating.mean().reset_index()
        plot(px.bar(d, x="department", y="rating", title="Average rating by department", color="department",
                    color_discrete_sequence=U.PALETTE, range_y=[0, 5]), 320)
    with b:
        plot(px.histogram(df, x="rating", nbins=9, title="Rating distribution", color_discrete_sequence=["#ec4899"]), 320)
    table(df.drop(columns=["id"]).rename(columns=lambda c: c.replace("_", " ").title()))
    csv_button(df, "performance_reviews.csv", key="pf_csv")
    delete_control("reviews", df.id.tolist(), "review", "pf_del", can("approve_leave"))


# --------------------------------------------------------------------------- #
# Training & certifications
# --------------------------------------------------------------------------- #
def page_training():
    header("training", "Track trainings and certifications, including certificate expiry dates.")
    with st.expander("➕ Add training / certification", expanded=False):
        pick = emp_select("Employee", "tr_emp", statuses=["Active", "On Leave"])
        if pick:
            with st.form("train_form"):
                c1, c2, c3 = st.columns(3)
                title = c1.text_input("Title *")
                prov = c2.text_input("Provider")
                kind = c3.selectbox("Type", ["Training", "Certification"])
                sd = c1.date_input("Start date", date.today())
                ed_ = c2.date_input("End date", date.today())
                status = c3.selectbox("Status", ["Planned", "In Progress", "Completed"])
                has_exp = st.checkbox("Certificate has an expiry date")
                exp = st.date_input("Certificate expiry", date.today() + timedelta(days=365))
                notes = st.text_input("Notes")
                go_ = st.form_submit_button("💾 Save record")
            if go_:
                if not title.strip():
                    st.error("Title is required.")
                elif ed_ < sd:
                    st.error("End date cannot be before start date.")
                else:
                    db.run("INSERT INTO trainings(emp_id,title,provider,kind,start_date,end_date,status,certificate_expiry,notes) "
                           "VALUES(?,?,?,?,?,?,?,?,?)", (pick, title, prov, kind, sd.isoformat(), ed_.isoformat(), status,
                                                        exp.isoformat() if has_exp else None, notes))
                    audit("ADD_TRAINING", f"{pick}: {title}")
                    flash("Record saved.")
                    st.rerun()
    df = db.q("SELECT t.id, t.emp_id, e.name, t.title, t.provider, t.kind, t.start_date, t.end_date, t.status, "
              "t.certificate_expiry, t.notes FROM trainings t JOIN employees e ON e.emp_id=t.emp_id ORDER BY t.start_date DESC")
    if df.empty:
        st.info("No training records yet.")
        return
    today = date.today().isoformat()
    exp_soon = int(((df.certificate_expiry.notna()) & (df.certificate_expiry >= today) &
                    (df.certificate_expiry <= (date.today() + timedelta(days=60)).isoformat())).sum())
    st.markdown(U.kpi_cards([("🎓", "Total records", len(df), ""), ("✅", "Completed", int((df.status == "Completed").sum()), ""),
                             ("🏅", "Certifications", int((df.kind == "Certification").sum()), ""),
                             ("⏳", "Certificates expiring in 60 days", exp_soon, "")]), unsafe_allow_html=True)
    f1, f2 = st.columns(2)
    k = f1.selectbox("Type", ["All", "Training", "Certification"], key="tr_f_kind")
    s_ = f2.selectbox("Status", ["All", "Planned", "In Progress", "Completed"], key="tr_f_stat")
    if k != "All":
        df = df[df.kind == k]
    if s_ != "All":
        df = df[df.status == s_]
    table(df.drop(columns=["id"]).rename(columns=lambda c: c.replace("_", " ").title()), badge_cols=("Status", "Kind"))
    csv_button(df, "training_records.csv", key="tr_csv")
    delete_control("trainings", df.id.tolist(), "training record", "tr_del", can("approve_leave"))


# --------------------------------------------------------------------------- #
# Holiday calendar
# --------------------------------------------------------------------------- #
def page_holidays():
    header("holidays", "Company holiday calendar - holidays also pre-fill attendance.")
    c1, c2 = st.columns(2)
    year = c1.number_input("Year", 2000, 2100, date.today().year, key="hol_year")
    month = c2.selectbox("Month", list(range(1, 13)), index=date.today().month - 1,
                         format_func=lambda m: date(2000, m, 1).strftime("%B"), key="hol_month")
    hols = db.q("SELECT id, date, name, kind FROM holidays ORDER BY date")
    hmap = {U.to_date(r.date): r.name for r in hols.itertuples()}
    st.markdown(f"#### {date(int(year), int(month), 1):%B %Y}")
    st.markdown(U.holiday_calendar_html(int(year), int(month), hmap), unsafe_allow_html=True)
    a, b = st.columns([2, 1])
    with a:
        yr = hols[hols.date.str.startswith(str(int(year)))]
        st.markdown(f"#### Holidays in {int(year)} ({len(yr)})")
        table(yr.drop(columns=["id"]).rename(columns=lambda c: c.replace("_", " ").title()), badge_cols=("Kind",))
        csv_button(yr, f"holidays_{int(year)}.csv", key="hol_csv")
    with b:
        st.markdown("#### ➕ Add holiday")
        with st.form("hol_form", clear_on_submit=True):
            d = st.date_input("Date", date.today())
            name = st.text_input("Holiday name *")
            kind = st.selectbox("Type", ["National", "Company", "Optional"])
            go_ = st.form_submit_button("Add holiday")
        if go_:
            if not name.strip():
                st.error("Holiday name is required.")
            elif db.one("SELECT 1 FROM holidays WHERE date=?", (d.isoformat(),)):
                st.error("A holiday already exists on that date.")
            else:
                db.run("INSERT INTO holidays(date,name,kind) VALUES(?,?,?)", (d.isoformat(), name.strip(), kind))
                audit("ADD_HOLIDAY", f"{d} {name}")
                flash("Holiday added.")
                st.rerun()
    delete_control("holidays", hols.id.tolist(), "holiday", "hol_del", can("approve_leave"))


# --------------------------------------------------------------------------- #
# Documents & expiry reminders
# --------------------------------------------------------------------------- #
DOC_TYPES = ["Passport", "Visa", "Work Permit", "Driving License", "ID Proof", "Employment Contract", "Medical Certificate",
             "Professional Certificate", "Other"]


def page_documents():
    header("documents", "Track employee documents and get reminders before they expire.")
    with st.expander("➕ Add a document record", expanded=False):
        pick = emp_select("Employee", "doc_emp")
        if pick:
            with st.form("doc_form"):
                c1, c2 = st.columns(2)
                dt = c1.selectbox("Document type", DOC_TYPES)
                num = c2.text_input("Document number")
                issue = c1.date_input("Issue date", date.today())
                exp = c2.date_input("Expiry date", date.today() + timedelta(days=365))
                notes = st.text_input("Notes")
                go_ = st.form_submit_button("💾 Save document")
            if go_:
                if exp < issue:
                    st.error("Expiry date cannot be before the issue date.")
                else:
                    db.run("INSERT INTO documents(emp_id,doc_type,doc_number,issue_date,expiry_date,notes) VALUES(?,?,?,?,?,?)",
                           (pick, dt, num, issue.isoformat(), exp.isoformat(), notes))
                    audit("ADD_DOCUMENT", f"{pick}: {dt}")
                    flash("Document saved.")
                    st.rerun()
    df = db.q("SELECT d.id, d.emp_id, e.name, d.doc_type, d.doc_number, d.issue_date, d.expiry_date, d.notes FROM documents d "
              "JOIN employees e ON e.emp_id=d.emp_id ORDER BY d.expiry_date")
    if df.empty:
        st.info("No documents recorded yet.")
        return
    today = date.today()
    df["days_left"] = [(U.to_date(x) - today).days for x in df.expiry_date]
    df["status"] = ["Expired" if d < 0 else "Expiring Soon" if d <= 30 else "Valid" for d in df.days_left]
    st.markdown(U.kpi_cards([("❌", "Expired", int((df.days_left < 0).sum()), "Needs renewal"),
                             ("⏰", "Expiring ≤ 30 days", int(((df.days_left >= 0) & (df.days_left <= 30)).sum()), ""),
                             ("📅", "Expiring 31-60 days", int(((df.days_left > 30) & (df.days_left <= 60)).sum()), ""),
                             ("✅", "Valid", int((df.days_left > 30).sum()), "")]), unsafe_allow_html=True)
    for r in df[df.days_left <= 30].head(8).itertuples():
        msg = (f"<b>{r.name}</b>'s {r.doc_type} {'expired ' + str(-r.days_left) + ' day(s) ago' if r.days_left < 0 else 'expires in ' + str(r.days_left) + ' day(s)'}"
               f" ({r.expiry_date})")
        st.markdown(U.alert_box(msg, "bad" if r.days_left < 0 else "warn"), unsafe_allow_html=True)
    window = st.selectbox("Show", ["All documents", "Expired", "Expiring within 30 days", "Expiring within 60 days", "Expiring within 90 days"],
                          key="doc_window")
    v = df
    if window == "Expired":
        v = df[df.days_left < 0]
    elif window.startswith("Expiring within"):
        n = int(window.split()[2])
        v = df[(df.days_left >= 0) & (df.days_left <= n)]
    table(v.drop(columns=["id"]).rename(columns=lambda c: c.replace("_", " ").title()), badge_cols=("Status",))
    csv_button(v, "document_expiry.csv", key="doc_csv")
    delete_control("documents", df.id.tolist(), "document", "doc_del", can("approve_leave"))


# --------------------------------------------------------------------------- #
# Loans & salary advances
# --------------------------------------------------------------------------- #
def page_loans():
    header("loans", "Track employee loans and salary advances. EMIs are deducted automatically in payroll.")
    with st.expander("➕ New loan / salary advance", expanded=False):
        pick = emp_select("Employee", "ln_emp", statuses=["Active", "On Leave"])
        if pick:
            with st.form("loan_form"):
                c1, c2 = st.columns(2)
                typ = c1.selectbox("Type", ["Loan", "Salary Advance"])
                amt = c2.number_input("Amount", min_value=0.0, step=1000.0, value=10000.0)
                emi = c1.number_input("Monthly deduction", min_value=0.0, step=500.0, value=2000.0)
                start = c2.date_input("Start date", date.today())
                notes = st.text_input("Notes")
                go_ = st.form_submit_button("💾 Save")
            if go_:
                if amt <= 0 or emi <= 0:
                    st.error("Amount and monthly deduction must be greater than zero.")
                elif emi > amt:
                    st.error("Monthly deduction cannot exceed the amount.")
                else:
                    db.run("INSERT INTO loans(emp_id,loan_type,amount,monthly_deduction,balance,start_date,status,notes) "
                           "VALUES(?,?,?,?,?,?,'Active',?)", (pick, typ, amt, emi, amt, start.isoformat(), notes))
                    audit("ADD_LOAN", f"{pick}: {typ} {amt}")
                    flash(f"{typ} recorded.")
                    st.rerun()
    df = db.q("SELECT l.id, l.emp_id, e.name, l.loan_type, l.amount, l.monthly_deduction, l.balance, l.start_date, l.status, l.notes "
              "FROM loans l JOIN employees e ON e.emp_id=l.emp_id ORDER BY l.status, l.id DESC")
    if df.empty:
        st.info("No loans or advances yet.")
        return
    act = df[df.status == "Active"]
    st.markdown(U.kpi_cards([("🏦", "Active loans/advances", len(act), ""), ("💰", "Outstanding balance", money(act.balance.sum()), ""),
                             ("📆", "Monthly recovery", money(act.monthly_deduction.sum()), ""),
                             ("✅", "Closed", int((df.status == "Closed").sum()), "")]), unsafe_allow_html=True)
    df["repaid_%"] = ((1 - df.balance / df.amount) * 100).round(1)
    table(df.drop(columns=["id"]).rename(columns=lambda c: c.replace("_", " ").title()),
          badge_cols=("Status", "Loan Type"), money_cols=("Amount", "Monthly Deduction", "Balance"))
    csv_button(df, "loans.csv", key="ln_csv")
    with st.expander("💵 Record a manual repayment / close a loan"):
        ids = act.id.tolist()
        if ids:
            lid = st.selectbox("Loan ID", ids, key="ln_pay_id")
            row = act[act.id == lid].iloc[0]
            amt = st.number_input("Repayment amount", min_value=0.0, max_value=float(row.balance), value=float(min(row.balance, row.monthly_deduction)),
                                  step=500.0, key="ln_pay_amt")
            if st.button("Record repayment", key="ln_pay_btn", disabled=amt <= 0):
                nb = round(float(row.balance) - amt, 2)
                db.run("UPDATE loans SET balance=?, status=? WHERE id=?", (nb, "Closed" if nb <= 0.01 else "Active", int(lid)))
                audit("LOAN_REPAYMENT", f"Loan #{lid} repayment {amt}")
                flash("Repayment recorded.")
                st.rerun()
        else:
            st.caption("No active loans.")
    delete_control("loans", df.id.tolist(), "loan", "ln_del", can("delete_employee"))


# --------------------------------------------------------------------------- #
# Reimbursements
# --------------------------------------------------------------------------- #
def page_reimbursements():
    header("reimbursements", "Submit, approve and track expense reimbursement claims. Approved claims are paid with payroll.")
    tabs = st.tabs(["📝 New Claim", "✅ Approvals", "📜 All Claims"])
    with tabs[0]:
        pick = emp_select("Employee", "rb_emp", statuses=["Active", "On Leave"])
        if pick:
            with st.form("rb_form"):
                c1, c2 = st.columns(2)
                cat = c1.selectbox("Category", ["Travel", "Medical", "Internet", "Training Material", "Food", "Equipment", "Other"])
                amt = c2.number_input("Amount", min_value=0.0, step=100.0, value=500.0)
                cd = c1.date_input("Claim date", date.today())
                desc = c2.text_input("Description")
                go_ = st.form_submit_button("📨 Submit claim")
            if go_:
                if amt <= 0:
                    st.error("Amount must be greater than zero.")
                else:
                    db.run("INSERT INTO reimbursements(emp_id,category,amount,claim_date,description,status) VALUES(?,?,?,?,?,'Pending')",
                           (pick, cat, amt, cd.isoformat(), desc))
                    audit("ADD_REIMBURSEMENT", f"{pick}: {cat} {amt}")
                    flash("Claim submitted for approval.")
                    st.rerun()
    with tabs[1]:
        pend = db.q("SELECT r.id, r.emp_id, e.name, r.category, r.amount, r.claim_date, r.description FROM reimbursements r "
                    "JOIN employees e ON e.emp_id=r.emp_id WHERE r.status='Pending' ORDER BY r.claim_date")
        if pend.empty:
            st.success("No pending claims. 🎉")
        elif not can("approve_reimbursement"):
            st.info("You do not have permission to approve claims.")
        else:
            for r in pend.itertuples():
                c = st.columns([3, 2, 1.2, 1.2])
                c[0].markdown(f"**{r.name}** ({r.emp_id})<br><small>{r.category} · {r.description or '-'}</small>", unsafe_allow_html=True)
                c[1].markdown(f"**{money(r.amount)}**<br><small>{r.claim_date}</small>", unsafe_allow_html=True)
                if c[2].button("✅ Approve", key=f"rb_ok_{r.id}"):
                    db.run("UPDATE reimbursements SET status='Approved', decided_by=? WHERE id=?", (me()["username"], r.id))
                    audit("APPROVE_REIMBURSEMENT", f"Claim #{r.id} {money(r.amount)}")
                    flash("Claim approved - it will be added to the next payroll run.")
                    st.rerun()
                if c[3].button("❌ Reject", key=f"rb_no_{r.id}"):
                    db.run("UPDATE reimbursements SET status='Rejected', decided_by=? WHERE id=?", (me()["username"], r.id))
                    audit("REJECT_REIMBURSEMENT", f"Claim #{r.id}")
                    flash("Claim rejected.", "warning")
                    st.rerun()
    with tabs[2]:
        df = db.q("SELECT r.id AS ID, r.emp_id AS Emp, e.name AS Name, r.category AS Category, r.amount AS Amount, "
                  "r.claim_date AS Date, r.description AS Description, r.status AS Status, r.payroll_month AS 'Paid in payroll' "
                  "FROM reimbursements r JOIN employees e ON e.emp_id=r.emp_id ORDER BY r.claim_date DESC")
        table(df, badge_cols=("Status",), money_cols=("Amount",))
        csv_button(df, "reimbursements.csv", key="rb_csv")


# --------------------------------------------------------------------------- #
# Resignation & final settlement
# --------------------------------------------------------------------------- #
def page_resignations():
    header("resignations", "Record resignations and calculate final settlements.")
    with st.expander("➕ Record a resignation & compute settlement", expanded=False):
        pick = emp_select("Employee", "rs_emp", statuses=["Active", "On Leave"])
        if pick:
            c1, c2, c3 = st.columns(3)
            rd = c1.date_input("Resignation date", date.today(), key="rs_rd")
            lwd = c2.date_input("Last working date", date.today() + timedelta(days=30), key="rs_lwd")
            req = c3.number_input("Notice days required", 0, 180, int(pr.fnum(S.get("notice_days"), 30)), key="rs_req")
            reason = st.text_input("Reason", key="rs_reason")
            served = max(0, (lwd - rd).days)
            if lwd < rd:
                st.error("Last working date cannot be before the resignation date.")
            else:
                calc = pr.calc_settlement(pick, lwd, req, served, S)
                items = pd.DataFrame([("Pending salary (pro-rata)", calc["pending_salary"]),
                                      ("Leave encashment (earned leave)", calc["leave_encashment"]),
                                      ("Gratuity (5+ years of service)", calc["gratuity"]),
                                      ("Approved reimbursements", calc["reimbursements"]),
                                      (f"Notice shortfall recovery ({max(0, req - served)} days)", -calc["notice_recovery"]),
                                      ("Outstanding loan/advance recovery", -calc["loan_recovery"]),
                                      ("NET SETTLEMENT", calc["net_settlement"])], columns=["Component", "Amount"])
                table(items, money_cols=("Amount",))
                st.caption("Notice served = days between resignation and last working date. Gratuity uses basic × 15/26 × completed years "
                           "(common Indian formula) - adjust to your policy/law.")
                if st.button("💾 Save resignation record", key="rs_save"):
                    if db.one("SELECT 1 FROM resignations WHERE emp_id=? AND status='Pending'", (pick,)):
                        st.error("This employee already has a pending resignation record.")
                    else:
                        db.run("INSERT INTO resignations(emp_id,resign_date,last_working_date,reason,notice_required,notice_served,"
                               "pending_salary,leave_encashment,gratuity,reimbursements,notice_recovery,loan_recovery,net_settlement,status) "
                               "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'Pending')",
                               (pick, rd.isoformat(), lwd.isoformat(), reason, req, served, calc["pending_salary"],
                                calc["leave_encashment"], calc["gratuity"], calc["reimbursements"], calc["notice_recovery"],
                                calc["loan_recovery"], calc["net_settlement"]))
                        audit("ADD_RESIGNATION", f"{pick} last day {lwd}")
                        flash("Resignation recorded. An Admin can complete the settlement.")
                        st.rerun()
    df = db.q("SELECT r.id, r.emp_id, e.name, r.resign_date, r.last_working_date, r.reason, r.net_settlement, r.status, r.settled_on "
              "FROM resignations r JOIN employees e ON e.emp_id=r.emp_id ORDER BY r.id DESC")
    if df.empty:
        st.info("No resignations recorded.")
        return
    st.markdown(U.kpi_cards([("🚪", "Total resignations", len(df), ""), ("⏳", "Pending settlements", int((df.status == "Pending").sum()), ""),
                             ("💰", "Pending amount", money(df[df.status == "Pending"].net_settlement.sum()), ""),
                             ("✅", "Settled", int((df.status == "Settled").sum()), "")]), unsafe_allow_html=True)
    table(df.rename(columns=lambda c: c.replace("_", " ").title()), badge_cols=("Status",), money_cols=("Net Settlement",))
    csv_button(df, "resignations.csv", key="rs_csv")
    st.markdown("#### 📄 Settlement details")
    rid = st.selectbox("Select record", df.id.tolist(), format_func=lambda i: f"#{i} · {df[df.id == i].name.iloc[0]}", key="rs_view")
    r = db.one("SELECT r.*, e.name FROM resignations r JOIN employees e ON e.emp_id=r.emp_id WHERE r.id=?", (int(rid),))
    det = pd.DataFrame([("Employee", f"{r['emp_id']} - {r['name']}"), ("Resignation date", r["resign_date"]),
                        ("Last working date", r["last_working_date"]), ("Notice required / served", f"{r['notice_required']} / {r['notice_served']} days"),
                        ("Pending salary", money(r["pending_salary"])), ("Leave encashment", money(r["leave_encashment"])),
                        ("Gratuity", money(r["gratuity"])), ("Reimbursements", money(r["reimbursements"])),
                        ("Notice recovery", "-" + money(r["notice_recovery"])), ("Loan recovery", "-" + money(r["loan_recovery"])),
                        ("Net settlement", money(r["net_settlement"])), ("Status", r["status"])], columns=["Item", "Value"])
    table(det)
    c1, c2 = st.columns(2)
    with c1:
        pdf = U.report_pdf("Final Settlement Statement", det, S, f"{r['emp_id']} - {r['name']}")
        st.download_button("⬇️ Settlement statement (PDF)", pdf, file_name=f"settlement_{r['emp_id']}.pdf", mime="application/pdf",
                           key=f"rs_pdf_{rid}")
    with c2:
        if r["status"] == "Pending":
            if can("complete_settlement"):
                if st.button("✅ Complete settlement & mark employee Inactive", key=f"rs_done_{rid}"):
                    db.run("UPDATE resignations SET status='Settled', settled_on=? WHERE id=?", (date.today().isoformat(), int(rid)))
                    db.run("UPDATE employees SET status='Inactive' WHERE emp_id=?", (r["emp_id"],))
                    audit("COMPLETE_SETTLEMENT", f"{r['emp_id']} settled {money(r['net_settlement'])}")
                    flash("Settlement completed. The employee is now Inactive.")
                    st.rerun()
            else:
                st.info("🔒 Only an Admin can complete a final settlement.")


# --------------------------------------------------------------------------- #
# Reports & analytics
# --------------------------------------------------------------------------- #
def page_reports():
    header("reports", "Export CSV / PDF reports, filter by month, department and employee, and explore trends.")
    tabs = st.tabs(["📑 Reports", "📈 Salary Trends & Department Statistics"])
    with tabs[0]:
        c1, c2, c3, c4 = st.columns(4)
        kind = c1.selectbox("Report", ["Employees", "Payroll", "Attendance", "Leaves"], key="rp_kind")
        months = ["All"] + U.month_options(24)
        month = c2.selectbox("Month", months, format_func=lambda m: "All months" if m == "All" else U.month_label(m), key="rp_month")
        edf = employees()
        dept = c3.selectbox("Department", ["All"] + sorted(edf.department.dropna().unique().tolist()), key="rp_dept")
        with c4:
            pick = emp_select("Employee", "rp_emp", allow_all=True)
        where, params = [], []
        if dept != "All":
            where.append("e.department=?")
            params.append(dept)
        if pick and pick != "__all__":
            where.append("e.emp_id=?")
            params.append(pick)
        money_cols = ()
        if kind == "Employees":
            sql = ("SELECT e.emp_id AS ID, e.name AS Name, e.department AS Department, e.designation AS Designation, e.email AS Email, "
                   "e.phone AS Phone, e.joining_date AS Joined, e.basic_salary AS 'Basic Salary', e.status AS Status FROM employees e")
            money_cols = ("Basic Salary",)
        elif kind == "Payroll":
            sql = ("SELECT p.month AS Month, e.emp_id AS ID, e.name AS Name, e.department AS Department, p.basic AS Basic, p.hra AS HRA, "
                   "p.da AS DA, p.allowances AS Allowances, p.bonus AS Bonus, p.overtime AS Overtime, p.reimbursements AS Reimb, "
                   "p.gross AS Gross, p.pf AS PF, p.tax AS Tax, p.prof_tax AS 'Prof Tax', p.loan_ded AS Loan, p.advance_ded AS Advance, "
                   "p.lop_amount AS LOP, p.other_ded AS Other, p.total_ded AS Deductions, p.net AS Net, p.status AS Status "
                   "FROM payroll p JOIN employees e ON e.emp_id=p.emp_id")
            money_cols = ("Basic", "HRA", "DA", "Allowances", "Bonus", "Overtime", "Reimb", "Gross", "PF", "Tax", "Prof Tax", "Loan",
                          "Advance", "LOP", "Other", "Deductions", "Net")
            if month != "All":
                where.append("p.month=?")
                params.append(month)
        elif kind == "Attendance":
            sql = ("SELECT a.date AS Date, e.emp_id AS ID, e.name AS Name, e.department AS Department, a.status AS Status, "
                   "a.check_in AS 'Check-in', a.check_out AS 'Check-out' FROM attendance a JOIN employees e ON e.emp_id=a.emp_id")
            if month != "All":
                where.append("a.date LIKE ?")
                params.append(month + "%")
        else:
            sql = ("SELECT l.start_date AS 'From', l.end_date AS 'To', e.emp_id AS ID, e.name AS Name, e.department AS Department, "
                   "l.leave_type AS Type, l.days AS Days, l.status AS Status, l.reason AS Reason FROM leaves l "
                   "JOIN employees e ON e.emp_id=l.emp_id")
            if month != "All":
                where.append("l.start_date LIKE ?")
                params.append(month + "%")
        if where:
            sql += " WHERE " + " AND ".join(where)
        rep = db.q(sql, tuple(params))
        summary = [("Records", len(rep))]
        if kind == "Payroll" and not rep.empty:
            summary += [("Gross", money(rep.Gross.sum())), ("Deductions", money(rep.Deductions.sum())), ("Net", money(rep.Net.sum()))]
        elif kind == "Employees" and not rep.empty:
            summary += [("Active", int((rep.Status == "Active").sum())), ("Total basic", money(rep["Basic Salary"].sum()))]
        elif kind == "Leaves" and not rep.empty:
            summary += [("Days", f"{rep.Days.sum():g}"), ("Pending", int((rep.Status == "Pending").sum()))]
        st.markdown(U.kpi_cards([("📄", a, b, "") for a, b in summary]), unsafe_allow_html=True)
        table(rep, badge_cols=("Status",), money_cols=money_cols, max_rows=100)
        flt = f"Month: {'All' if month == 'All' else U.month_label(month)} | Dept: {dept} | Employee: {pick if pick != '__all__' else 'All'}"
        d1, d2 = st.columns(2)
        with d1:
            csv_button(rep, f"{kind.lower()}_report.csv", key="rp_csv")
        with d2:
            pdf = U.report_pdf(f"{kind} Report", rep, S, flt, summary, money_cols=money_cols)
            st.download_button("⬇️ Download PDF report", pdf, file_name=f"{kind.lower()}_report.pdf", mime="application/pdf", key="rp_pdf")
    with tabs[1]:
        pay = db.q("SELECT p.month, e.department, p.gross, p.net, p.total_ded FROM payroll p JOIN employees e ON e.emp_id=p.emp_id")
        if pay.empty:
            st.info("Process payroll to see salary trends.")
        else:
            tr = pay.groupby("month")[["gross", "net", "total_ded"]].sum().reset_index().sort_values("month")
            fig = go.Figure()
            fig.add_scatter(x=tr.month, y=tr.gross, name="Gross", mode="lines+markers", line=dict(color="#7c3aed", width=3))
            fig.add_scatter(x=tr.month, y=tr.net, name="Net", mode="lines+markers", line=dict(color="#ec4899", width=3))
            fig.add_scatter(x=tr.month, y=tr.total_ded, name="Deductions", mode="lines+markers", line=dict(color="#3b82f6", width=3))
            fig.update_layout(title="Salary trend (total company payroll)")
            plot(fig)
            a, b = st.columns(2)
            with a:
                dm = pay.groupby(["month", "department"]).net.sum().reset_index()
                plot(px.area(dm, x="month", y="net", color="department", title="Net payroll by department",
                             color_discrete_sequence=U.PALETTE), 340)
            with b:
                last = pay[pay.month == pay.month.max()].groupby("department").net.sum().reset_index()
                plot(px.pie(last, names="department", values="net", hole=.45, title=f"Net salary share · {U.month_label(pay.month.max())}",
                            color_discrete_sequence=U.PALETTE), 340)
        e = employees()
        e = e[e.status != "Inactive"]
        stats = e.groupby("department").agg(Headcount=("emp_id", "count"), Avg_Basic=("basic_salary", "mean"),
                                           Min_Basic=("basic_salary", "min"), Max_Basic=("basic_salary", "max"),
                                           Total_Basic=("basic_salary", "sum")).reset_index().round(0)
        stats.columns = [c.replace("_", " ") for c in stats.columns]
        st.markdown("#### Department statistics")
        table(stats, money_cols=("Avg Basic", "Min Basic", "Max Basic", "Total Basic"))
        plot(px.bar(stats, x="department" if "department" in stats.columns else "Department", y="Avg Basic",
                    title="Average basic salary by department", color="Headcount", color_continuous_scale=["#f9a8d4", "#7c3aed"]), 320)
        csv_button(stats, "department_statistics.csv", key="dept_csv")


# --------------------------------------------------------------------------- #
# Audit logs
# --------------------------------------------------------------------------- #
def page_audit():
    header("audit", "A record of important actions: who did what and when.")
    if not can("audit"):
        st.error("Only an Admin can view audit logs.")
        return
    df = db.q("SELECT id, ts, username, action, details FROM audit_logs ORDER BY id DESC LIMIT 2000")
    c1, c2, c3 = st.columns(3)
    user = c1.selectbox("User", ["All"] + sorted(df.username.unique().tolist()), key="au_user")
    act = c2.selectbox("Action", ["All"] + sorted(df.action.unique().tolist()), key="au_act")
    text = c3.text_input("Search details", key="au_text")
    if user != "All":
        df = df[df.username == user]
    if act != "All":
        df = df[df.action == act]
    if text:
        df = df[df.details.fillna("").str.contains(text, case=False, regex=False)]
    st.caption(f"{len(df)} log entries (latest 2000 loaded)")
    table(df.rename(columns={"ts": "Time", "username": "User", "action": "Action", "details": "Details", "id": "#"}), max_rows=200)
    csv_button(df, "audit_logs.csv", key="au_csv")


# --------------------------------------------------------------------------- #
# Settings
# --------------------------------------------------------------------------- #
def settings_company():
    with st.form("company_form"):
        c1, c2 = st.columns(2)
        name = c1.text_input("Company name", S["company_name"])
        email = c2.text_input("Company email", S["company_email"])
        phone = c1.text_input("Phone", S["company_phone"])
        curs = ["₹", "$", "€", "£", "¥", "AED"]
        curr = c2.selectbox("Currency symbol", curs, index=curs.index(S["currency"]) if S["currency"] in curs else 0)
        addr = st.text_area("Address", S["company_address"], height=70)
        logo = st.file_uploader("Company logo (PNG/JPG)", type=["png", "jpg", "jpeg"])
        rm = st.checkbox("Remove current logo")
        go_ = st.form_submit_button("💾 Save company settings")
    if S.get("logo_b64"):
        import base64
        st.image(base64.b64decode(S["logo_b64"]), width=120, caption="Current logo")
    if go_:
        if not name.strip():
            st.error("Company name is required.")
            return
        for k, v in dict(company_name=name.strip(), company_email=email, company_phone=phone, currency=curr, company_address=addr).items():
            db.set_setting(k, v)
        if logo:
            db.set_setting("logo_b64", U.logo_to_b64(logo))
        elif rm:
            db.set_setting("logo_b64", "")
        audit("UPDATE_SETTINGS", "Company settings updated")
        flash("Company settings saved.")
        st.rerun()


def settings_payroll():
    with st.form("payroll_settings"):
        st.markdown("**Salary structure**")
        c = st.columns(4)
        hra = c[0].number_input("HRA % of basic", 0.0, 100.0, pr.fnum(S["hra_pct"]), 1.0)
        da = c[1].number_input("DA % of basic", 0.0, 100.0, pr.fnum(S["da_pct"]), 1.0)
        allow = c[2].number_input("Default allowance", 0.0, 1e7, pr.fnum(S["default_allowance"]), 100.0)
        otm = c[3].number_input("Overtime multiplier", 1.0, 5.0, pr.fnum(S["overtime_multiplier"]), 0.25)
        c = st.columns(3)
        wd = c[0].number_input("Paying days per month", 20.0, 31.0, pr.fnum(S["working_days"]), 1.0)
        hpd = c[1].number_input("Standard hours per day", 4.0, 14.0, pr.fnum(S["hours_per_day"]), 0.5)
        notice = c[2].number_input("Default notice period (days)", 0, 180, int(pr.fnum(S["notice_days"])), 1)
        st.markdown("**Provident fund & taxes**")
        c = st.columns(4)
        pf = c[0].number_input("PF rate %", 0.0, 30.0, pr.fnum(S["pf_rate"]), 0.5)
        pfc = c[1].number_input("PF wage cap (0 = none)", 0.0, 1e7, pr.fnum(S["pf_wage_cap"]), 500.0)
        pt = c[2].number_input("Professional tax", 0.0, 1e5, pr.fnum(S["prof_tax"]), 10.0)
        ptt = c[3].number_input("Prof. tax applies from pay", 0.0, 1e7, pr.fnum(S["prof_tax_threshold"]), 500.0)
        c = st.columns(4)
        l1 = c[0].number_input("Tax-free monthly slab", 0.0, 1e8, pr.fnum(S["tax_slab1_limit"]), 1000.0)
        l2 = c[1].number_input("Slab 2 upper limit", 0.0, 1e8, pr.fnum(S["tax_slab2_limit"]), 1000.0)
        p2 = c[2].number_input("Slab 2 tax %", 0.0, 60.0, pr.fnum(S["tax_slab2_pct"]), 0.5)
        p3 = c[3].number_input("Slab 3 tax %", 0.0, 60.0, pr.fnum(S["tax_slab3_pct"]), 0.5)
        st.markdown("**Attendance integration & leave quotas**")
        c = st.columns(5)
        lop = c[0].checkbox("Deduct LOP for absences", S["apply_lop"] == "1")
        otf = c[1].checkbox("Overtime from attendance", S["ot_from_attendance"] == "1")
        qc = c[2].number_input("Casual leave / yr", 0, 60, int(pr.fnum(S["quota_casual"])))
        qs = c[3].number_input("Sick leave / yr", 0, 60, int(pr.fnum(S["quota_sick"])))
        qe = c[4].number_input("Earned leave / yr", 0, 60, int(pr.fnum(S["quota_earned"])))
        go_ = st.form_submit_button("💾 Save payroll settings")
    if go_:
        if l2 < l1:
            st.error("Slab 2 upper limit must be greater than or equal to the tax-free slab.")
            return
        vals = dict(hra_pct=hra, da_pct=da, default_allowance=allow, overtime_multiplier=otm, working_days=wd, hours_per_day=hpd,
                    notice_days=notice, pf_rate=pf, pf_wage_cap=pfc, prof_tax=pt, prof_tax_threshold=ptt, tax_slab1_limit=l1,
                    tax_slab2_limit=l2, tax_slab2_pct=p2, tax_slab3_pct=p3, apply_lop="1" if lop else "0",
                    ot_from_attendance="1" if otf else "0", quota_casual=qc, quota_sick=qs, quota_earned=qe)
        for k, v in vals.items():
            db.set_setting(k, v)
        audit("UPDATE_SETTINGS", "Payroll settings updated")
        flash("Payroll settings saved. They apply to payroll processed from now on.")
        st.rerun()


def settings_users():
    users = db.q("SELECT id, username, full_name, role, active, created_at FROM users ORDER BY id")
    users["active"] = users.active.map({1: "Active", 0: "Inactive"})
    table(users.rename(columns={"id": "#", "username": "Username", "full_name": "Name", "role": "Role", "active": "Status",
                                "created_at": "Created"}), badge_cols=("Status",))
    a, b = st.columns(2)
    with a:
        st.markdown("##### ➕ Add user")
        with st.form("add_user", clear_on_submit=True):
            un = st.text_input("Username *")
            fn = st.text_input("Full name")
            role = st.selectbox("Role", ["hr", "admin"], help="HR: no payroll approval, settings, users, backup or audit logs.")
            pw = st.text_input("Password * (min 8 characters)", type="password")
            go_ = st.form_submit_button("Create user")
        if go_:
            if not un.strip() or len(pw) < 8:
                st.error("Username is required and the password must be at least 8 characters.")
            elif db.one("SELECT 1 FROM users WHERE username=?", (un.strip(),)):
                st.error("That username already exists.")
            else:
                db.run("INSERT INTO users(username,password_hash,full_name,role,created_at) VALUES(?,?,?,?,?)",
                       (un.strip(), U.hash_password(pw), fn, role, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                audit("ADD_USER", f"Created user {un} ({role})")
                flash(f"User {un} created.")
                st.rerun()
    with b:
        st.markdown("##### 🔧 Manage user")
        uid = st.selectbox("User", users["id"].tolist(), format_func=lambda i: users[users.id == i].username.iloc[0], key="mu_user")
        uname = users[users.id == uid].username.iloc[0]
        with st.form("reset_pw", clear_on_submit=True):
            npw = st.text_input("New password (min 8 characters)", type="password")
            go_ = st.form_submit_button("Reset password")
        if go_:
            if len(npw) < 8:
                st.error("Password must be at least 8 characters.")
            else:
                db.run("UPDATE users SET password_hash=? WHERE id=?", (U.hash_password(npw), int(uid)))
                audit("RESET_PASSWORD", f"Password reset for {uname}")
                flash(f"Password for {uname} updated.")
                st.rerun()
        is_self = uname == me()["username"]
        cur_active = users[users.id == uid].active.iloc[0] == "Active"
        if st.button(("🚫 Deactivate " if cur_active else "✅ Activate ") + uname, disabled=is_self, key="mu_toggle"):
            db.run("UPDATE users SET active=? WHERE id=?", (0 if cur_active else 1, int(uid)))
            audit("TOGGLE_USER", f"{uname} -> {'inactive' if cur_active else 'active'}")
            flash("User updated.")
            st.rerun()
        if is_self:
            st.caption("You cannot deactivate your own account.")


def settings_backup():
    st.warning("⚠️ **Persistence note:** on Streamlit Community Cloud the app's disk is *ephemeral* - the SQLite file can be reset "
               "when the app restarts, redeploys or goes to sleep. Download a backup regularly and restore it here after a reset.")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### 💾 Backup")
        st.write("Download a complete snapshot of all data (employees, payroll, attendance, users, settings, photos...).")
        st.download_button("⬇️ Download database backup", db.backup_bytes(),
                           file_name=f"payroll_backup_{datetime.now():%Y%m%d_%H%M}.db", mime="application/octet-stream",
                           key="bk_dl", on_click=lambda: audit("BACKUP", "Database backup downloaded"))
    with c2:
        st.markdown("##### ♻️ Restore")
        up = st.file_uploader("Upload a .db backup", type=["db", "sqlite", "sqlite3"], key="bk_up")
        ok = st.checkbox("I understand this will REPLACE all current data", key="bk_ok")
        if st.button("Restore database", disabled=not (up and ok), key="bk_btn"):
            good, msg = db.restore_from_bytes(up.getvalue())
            if good:
                db.log_action(me()["username"], "RESTORE", "Database restored from backup")
                st.session_state.pop("user", None)
                st.session_state["_flash"] = ("Database restored. Please sign in again.", "success")
                st.rerun()
            else:
                st.error(msg)


def settings_account():
    u = me()
    st.markdown(f"**{u['full_name'] or u['username']}** · username `{u['username']}` · role {U.badge(u['role'].upper())}",
                unsafe_allow_html=True)
    with st.form("chg_pw", clear_on_submit=True):
        cur_pw = st.text_input("Current password", type="password")
        n1 = st.text_input("New password (min 8 characters)", type="password")
        n2 = st.text_input("Confirm new password", type="password")
        go_ = st.form_submit_button("🔑 Change password")
    if go_:
        row = db.one("SELECT password_hash FROM users WHERE id=?", (u["id"],))
        if not U.verify_password(cur_pw, row["password_hash"]):
            st.error("Current password is incorrect.")
        elif len(n1) < 8:
            st.error("New password must be at least 8 characters.")
        elif n1 != n2:
            st.error("The new passwords do not match.")
        else:
            db.run("UPDATE users SET password_hash=? WHERE id=?", (U.hash_password(n1), u["id"]))
            audit("CHANGE_PASSWORD", "Password changed")
            flash("Password changed.")
            st.rerun()
    st.caption("Language and light/dark theme can be changed from the sidebar; your choice is remembered for your account.")


def page_settings():
    header("settings", "Company profile, payroll rules, users, backup and your account.")
    entries = []
    if can("company_settings"):
        entries += [("🏢 Company", settings_company), ("💰 Payroll Settings", settings_payroll),
                    ("👤 Users & Roles", settings_users), ("💾 Backup & Restore", settings_backup)]
    entries.append(("🔑 My Account", settings_account))
    tabs = st.tabs([e[0] for e in entries])
    for tab, (_, fn) in zip(tabs, entries):
        with tab:
            fn()
    if not can("company_settings"):
        st.info("🔒 Company, payroll, user and backup settings are available to Admins only.")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
PAGE_FUNCS = {"dashboard": page_dashboard, "employees": page_employees, "payroll": page_payroll, "payslips": page_payslips,
              "attendance": page_attendance, "leaves": page_leaves, "performance": page_performance, "training": page_training,
              "holidays": page_holidays, "documents": page_documents, "loans": page_loans, "reimbursements": page_reimbursements,
              "resignations": page_resignations, "reports": page_reports, "audit": page_audit, "settings": page_settings}


def sidebar(allowed):
    u = me()
    with st.sidebar:
        if S.get("logo_b64"):
            import base64
            st.image(base64.b64decode(S["logo_b64"]), width=90)
        st.markdown(f"## 💼 {t('app_title')}")
        st.markdown(f"**{S.get('company_name', '')}**")
        st.markdown(f"👤 {u['full_name'] or u['username']} · `{u['role'].upper()}`")
        st.selectbox("🌐 " + t("language"), list(U.LANGS), format_func=U.LANGS.get, key="lang")
        st.toggle("🌙 " + t("dark_mode"), key="dark")
        if st.session_state["lang"] != u["lang"] or (st.session_state["dark"] != (u["theme"] == "dark")):
            theme = "dark" if st.session_state["dark"] else "light"
            db.run("UPDATE users SET lang=?, theme=? WHERE id=?", (st.session_state["lang"], theme, u["id"]))
            u["lang"], u["theme"] = st.session_state["lang"], theme
        st.markdown("---")
        if "_goto" in st.session_state:
            target = st.session_state.pop("_goto")
            if target in allowed:
                st.session_state["nav"] = target
        if st.session_state.get("nav") not in allowed:
            st.session_state["nav"] = allowed[0]
        page = st.radio("Navigation", allowed, key="nav", label_visibility="collapsed",
                        format_func=lambda k: f"{ICON[k]}  {t(k)}")
        st.markdown("---")
        if st.button("🚪 " + t("logout"), key="logout"):
            db.log_action(u["username"], "LOGOUT", "Signed out")
            for k in ["user", "nav", "lang", "dark"]:
                st.session_state.pop(k, None)
            st.rerun()
    return page


def main():
    global S
    boot()
    if "user" not in st.session_state:
        login_page()
        return
    S = db.get_settings()
    allowed = [k for k, _ in PAGES if can(k)]
    st.session_state.setdefault("lang", me()["lang"] or "en")
    st.session_state.setdefault("dark", me()["theme"] == "dark")
    page = sidebar(allowed)
    st.markdown(U.get_css(U.is_dark()), unsafe_allow_html=True)
    try:
        PAGE_FUNCS[page]()
    except Exception as exc:  # keep the app usable and show a friendly message
        st.error(f"Something went wrong on this page: {exc}")
        st.exception(exc)


main()
