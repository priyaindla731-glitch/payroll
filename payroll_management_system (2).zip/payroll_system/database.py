"""database.py - SQLite storage layer for the Employee Payroll Management System.

A new connection is opened per call (cheap for SQLite and safe with Streamlit's
threaded reruns). All dates are ISO strings (YYYY-MM-DD) and months are YYYY-MM.
"""
import os
import sqlite3
import tempfile
import shutil
from datetime import datetime

import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("PAYROLL_DB_PATH", os.path.join(BASE_DIR, "payroll.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    role TEXT NOT NULL DEFAULT 'hr',
    active INTEGER DEFAULT 1,
    theme TEXT DEFAULT 'light',
    lang TEXT DEFAULT 'en',
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS employees(
    emp_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT, phone TEXT, address TEXT,
    department TEXT, designation TEXT,
    joining_date TEXT, dob TEXT,
    basic_salary REAL DEFAULT 0,
    fixed_allowance REAL DEFAULT 0,
    status TEXT DEFAULT 'Active',
    bank_account TEXT,
    photo BLOB
);
CREATE TABLE IF NOT EXISTS salary_revisions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    old_salary REAL, new_salary REAL, effective_date TEXT, reason TEXT, created_by TEXT
);
CREATE TABLE IF NOT EXISTS promotions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    old_designation TEXT, new_designation TEXT,
    old_department TEXT, new_department TEXT,
    effective_date TEXT, remarks TEXT
);
CREATE TABLE IF NOT EXISTS payroll(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    month TEXT NOT NULL,
    basic REAL, hra REAL, da REAL, allowances REAL, bonus REAL, overtime REAL,
    reimbursements REAL, gross REAL,
    pf REAL, tax REAL, prof_tax REAL, loan_ded REAL, advance_ded REAL,
    lop_days REAL, lop_amount REAL, other_ded REAL, total_ded REAL, net REAL,
    status TEXT DEFAULT 'Pending Approval',
    processed_by TEXT, processed_at TEXT, approved_by TEXT, approved_at TEXT,
    UNIQUE(emp_id, month)
);
CREATE TABLE IF NOT EXISTS attendance(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    date TEXT NOT NULL, status TEXT NOT NULL, check_in TEXT, check_out TEXT,
    UNIQUE(emp_id, date)
);
CREATE TABLE IF NOT EXISTS leaves(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    leave_type TEXT, start_date TEXT, end_date TEXT, days REAL, reason TEXT,
    status TEXT DEFAULT 'Pending', applied_on TEXT, decided_by TEXT, decided_on TEXT
);
CREATE TABLE IF NOT EXISTS reviews(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    period TEXT, rating REAL, reviewer TEXT, strengths TEXT, improvements TEXT,
    comments TEXT, review_date TEXT
);
CREATE TABLE IF NOT EXISTS trainings(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    title TEXT, provider TEXT, kind TEXT, start_date TEXT, end_date TEXT,
    status TEXT, certificate_expiry TEXT, notes TEXT
);
CREATE TABLE IF NOT EXISTS documents(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    doc_type TEXT, doc_number TEXT, issue_date TEXT, expiry_date TEXT, notes TEXT
);
CREATE TABLE IF NOT EXISTS holidays(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT UNIQUE NOT NULL, name TEXT, kind TEXT
);
CREATE TABLE IF NOT EXISTS loans(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    loan_type TEXT, amount REAL, monthly_deduction REAL, balance REAL,
    start_date TEXT, status TEXT DEFAULT 'Active', notes TEXT
);
CREATE TABLE IF NOT EXISTS reimbursements(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    category TEXT, amount REAL, claim_date TEXT, description TEXT,
    status TEXT DEFAULT 'Pending', decided_by TEXT, payroll_month TEXT
);
CREATE TABLE IF NOT EXISTS resignations(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emp_id TEXT NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
    resign_date TEXT, last_working_date TEXT, reason TEXT,
    notice_required INTEGER, notice_served INTEGER,
    pending_salary REAL, leave_encashment REAL, gratuity REAL,
    reimbursements REAL, notice_recovery REAL, loan_recovery REAL, net_settlement REAL,
    status TEXT DEFAULT 'Pending', settled_on TEXT
);
CREATE TABLE IF NOT EXISTS audit_logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT, username TEXT, action TEXT, details TEXT
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
"""

DEFAULT_SETTINGS = {
    "company_name": "Sample Company Pvt. Ltd.",
    "company_address": "12 Business Park, Hyderabad, Telangana 500081",
    "company_phone": "+91 40 1234 5678",
    "company_email": "hr@samplecompany.com",
    "logo_b64": "",
    "currency": "₹",
    "working_days": "26",          # paying days per month (used for per-day rate)
    "hours_per_day": "9",          # standard hours; time beyond this counts as overtime
    "hra_pct": "40",               # % of basic
    "da_pct": "10",                # % of basic
    "default_allowance": "2000",   # default fixed allowance for new employees
    "overtime_multiplier": "1.5",
    "pf_rate": "12",               # % of (basic + DA)
    "pf_wage_cap": "0",            # 0 = no cap, e.g. 15000 to cap PF wages
    "tax_slab1_limit": "25000",    # monthly taxable income up to this is 0%
    "tax_slab2_limit": "75000",    # between slab1 and slab2 limits -> slab2 %
    "tax_slab2_pct": "5",
    "tax_slab3_pct": "10",         # above slab2 limit
    "prof_tax": "200",             # flat monthly professional tax
    "prof_tax_threshold": "15000", # applies when taxable pay >= this
    "apply_lop": "1",              # deduct salary for absent / unpaid-leave days
    "ot_from_attendance": "1",     # pre-fill overtime hours from attendance
    "quota_casual": "12",
    "quota_sick": "10",
    "quota_earned": "15",
    "notice_days": "30",
}


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def run(sql, params=()):
    """Execute a write statement; returns lastrowid."""
    conn = get_conn()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def run_many(sql, rows):
    conn = get_conn()
    try:
        conn.executemany(sql, rows)
        conn.commit()
    finally:
        conn.close()


def q(sql, params=()):
    """Run a SELECT and return a DataFrame."""
    conn = get_conn()
    try:
        return pd.read_sql_query(sql, conn, params=params)
    finally:
        conn.close()


def one(sql, params=()):
    """Return the first row as a dict (or None)."""
    conn = get_conn()
    try:
        row = conn.execute(sql, params).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def scalar(sql, params=(), default=0):
    r = one(sql, params)
    if not r:
        return default
    v = list(r.values())[0]
    return default if v is None else v


def get_settings():
    s = dict(DEFAULT_SETTINGS)
    conn = get_conn()
    try:
        for row in conn.execute("SELECT key, value FROM settings"):
            s[row["key"]] = row["value"]
    finally:
        conn.close()
    return s


def set_setting(key, value):
    run("INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def log_action(username, action, details=""):
    run("INSERT INTO audit_logs(ts,username,action,details) VALUES(?,?,?,?)",
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), username, action, details))


def next_emp_id():
    df = q("SELECT emp_id FROM employees")
    nums = [int(x[3:]) for x in df.emp_id if x.startswith("EMP") and x[3:].isdigit()]
    return f"EMP{(max(nums) + 1) if nums else 1:03d}"


def init_db():
    """Create tables, default settings, the first admin and (on a fresh DB) sample data."""
    conn = get_conn()
    try:
        conn.executescript(SCHEMA)
        conn.executemany("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",
                         list(DEFAULT_SETTINGS.items()))
        conn.commit()
    finally:
        conn.close()
    if scalar("SELECT COUNT(*) FROM users") == 0:
        import sample_data  # local import avoids a circular dependency
        if os.environ.get("PAYROLL_SEED_SAMPLE", "1") == "1":
            sample_data.seed()
        else:
            sample_data.create_default_users()


def backup_bytes():
    """Consistent snapshot of the whole database as bytes (uses SQLite's backup API)."""
    fd, tmp = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        src = sqlite3.connect(DB_PATH)
        dst = sqlite3.connect(tmp)
        src.backup(dst)
        dst.close()
        src.close()
        with open(tmp, "rb") as fh:
            return fh.read()
    finally:
        os.remove(tmp)


def restore_from_bytes(data):
    """Validate an uploaded SQLite file and replace the live database with it."""
    if not data or not data.startswith(b"SQLite format 3"):
        return False, "That file is not a valid SQLite database."
    fd, tmp = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        with open(tmp, "wb") as fh:
            fh.write(data)
        chk = sqlite3.connect(tmp)
        try:
            names = {r[0] for r in chk.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            chk.close()
        needed = {"users", "employees", "payroll", "settings"}
        if not needed.issubset(names):
            return False, "This backup is missing required tables: " + ", ".join(sorted(needed - names))
        shutil.copyfile(tmp, DB_PATH)
    except sqlite3.DatabaseError as exc:
        return False, f"Database error: {exc}"
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    init_db()  # add any tables/settings introduced after the backup was taken
    return True, "Database restored successfully."
